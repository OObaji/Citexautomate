<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Citex_AI_V2 {
	const OPTION_API_KEY = 'citex_gemini_api_key';
	const OPTION_MODEL = 'citex_gemini_model';
	const OPTION_WEB_VERIFY = 'citex_gemini_web_verify';
	const DEFAULT_MODEL = 'gemini-3.7-flash';
	const API_URL = 'https://generativelanguage.googleapis.com/v1beta/interactions';
	const MAX_QUALITY_ATTEMPTS = 3;

	public static function get_api_key() {
		$env = getenv( 'GEMINI_API_KEY' );
		return is_string( $env ) && '' !== trim( $env ) ? trim( $env ) : trim( (string) get_option( self::OPTION_API_KEY, '' ) );
	}
	public static function get_model() {
		$model = trim( (string) get_option( self::OPTION_MODEL, self::DEFAULT_MODEL ) );
		return '' !== $model ? $model : self::DEFAULT_MODEL;
	}
	public static function web_verification_enabled() { return (bool) get_option( self::OPTION_WEB_VERIFY, true ); }
	public static function save_settings( $api_key, $model, $web_verify ) {
		if ( '' !== trim( (string) $api_key ) ) { update_option( self::OPTION_API_KEY, trim( (string) $api_key ), false ); }
		update_option( self::OPTION_MODEL, '' !== trim( (string) $model ) ? sanitize_text_field( $model ) : self::DEFAULT_MODEL, false );
		update_option( self::OPTION_WEB_VERIFY, ! empty( $web_verify ), false );
	}
	public static function maybe_handle_submit() {
		if ( empty( $_POST['citex_ai_save_settings'] ) ) { return; }
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'You are not allowed to manage Citex AI settings.', 'citex-tools' ) ); }
		check_admin_referer( 'citex_ai_settings', 'citex_ai_settings_nonce' );
		self::save_settings( isset( $_POST['citex_gemini_api_key'] ) ? wp_unslash( $_POST['citex_gemini_api_key'] ) : '', isset( $_POST['citex_gemini_model'] ) ? wp_unslash( $_POST['citex_gemini_model'] ) : self::DEFAULT_MODEL, ! empty( $_POST['citex_gemini_web_verify'] ) );
		Citex_Admin::set_notice( __( 'Gemini AI settings saved.', 'citex-tools' ), 'success' );
		wp_safe_redirect( admin_url( 'admin.php?page=citex-ai' ) ); exit;
	}

	public static function render_settings() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'You are not allowed to manage Citex AI settings.', 'citex-tools' ) ); }
		self::maybe_handle_submit();
		$has_key = '' !== self::get_api_key(); $model = self::get_model(); $web_verify = self::web_verification_enabled();
		require CITEX_TOOLS_PATH . 'admin/views/ai-settings.php';
	}

	public static function generate_questions( $args ) {
		$key = self::get_api_key();
		if ( '' === $key ) { return new WP_Error( 'citex_ai_no_key', __( 'Gemini is not configured. Add a Gemini API key in Citex → AI Settings first.', 'citex-tools' ) ); }
		$quantity = max( 1, min( 100, absint( $args['quantity'] ?? 10 ) ) );
		$difficulty = sanitize_key( $args['difficulty'] ?? 'medium' );
		$verify = isset( $args['web_verify'] ) ? (bool) $args['web_verify'] : self::web_verification_enabled();
		// 'MCQ' is the only other supported type — anything else (including the
		// default) is the original DragDrop path, so this can never silently
		// switch an existing caller onto a different question shape. Same
		// principle for category: 'edited_book' is the only other supported
		// category — anything else stays the original Book path.
		$type     = 'mcq' === sanitize_key( $args['type'] ?? 'dragdrop' ) ? 'MCQ' : 'DragDrop';
		$category = 'edited_book' === sanitize_key( $args['category'] ?? 'book' ) ? Citex_Reference_Rules::CATEGORY_EDITED_BOOK : Citex_Reference_Rules::CATEGORY_BOOK;
		$ids = self::build_ids( strtoupper( sanitize_text_field( $args['starting_id'] ?? 'BK01' ) ), $quantity, $args['used_ids'] ?? array() );
		if ( is_wp_error( $ids ) ) { return $ids; }
		// Citex assigns each slot's Exercise deterministically before any
		// Gemini request is made (see Citex_Generator::build_exercise_assignments());
		// Gemini's schema has no exercise field, so nothing from its response
		// is ever consulted for this.
		$exercises = array_values( (array) ( $args['exercise_assignments'] ?? array() ) );

		$last_error = '';
		for ( $attempt = 1; $attempt <= self::MAX_QUALITY_ATTEMPTS; $attempt++ ) {
			$body = array(
				'model' => self::get_model(),
				'input' => self::build_prompt_for( $type, $category, $ids, $difficulty, $verify, $last_error ),
				'system_instruction' => self::system_instruction_for( $type, $category ),
				'response_format' => array( array( 'type' => 'text', 'mime_type' => 'application/json', 'schema' => self::schema_for( $type, $category ) ) ),
				'generation_config' => array( 'max_output_tokens' => max( 4000, min( 24000, $quantity * 650 ) ) ),
			);
			if ( $verify ) { $body['tools'] = array( array( 'type' => 'google_search' ) ); }
			$response = wp_remote_post( self::API_URL, array( 'timeout' => 120, 'headers' => array( 'Content-Type' => 'application/json', 'x-goog-api-key' => $key ), 'body' => wp_json_encode( $body ) ) );
			if ( is_wp_error( $response ) ) { return new WP_Error( 'citex_ai_request_failed', sprintf( __( 'Gemini request failed: %s', 'citex-tools' ), $response->get_error_message() ) ); }
			$code = (int) wp_remote_retrieve_response_code( $response ); $data = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( $code < 200 || $code >= 300 ) { $message = is_array( $data ) && isset( $data['error']['message'] ) ? $data['error']['message'] : __( 'Gemini returned an unexpected error.', 'citex-tools' ); return new WP_Error( 'citex_ai_api_error', sprintf( __( 'Gemini API error (%1$d): %2$s', 'citex-tools' ), $code, $message ) ); }
			$text = self::output_text( is_array( $data ) ? $data : array() ); $decoded = json_decode( self::strip_fences( $text ), true );
			if ( '' === $text || JSON_ERROR_NONE !== json_last_error() || ! is_array( $decoded ) ) { return new WP_Error( 'citex_ai_invalid_json', __( 'Gemini did not return valid structured question data.', 'citex-tools' ) ); }
			$questions = isset( $decoded['questions'] ) && is_array( $decoded['questions'] ) ? $decoded['questions'] : array();
			if ( count( $questions ) !== $quantity ) { $last_error = sprintf( 'The previous attempt returned %d questions instead of %d. Return exactly %d.', count( $questions ), $quantity, $quantity ); continue; }
			$result = self::normalise( $questions, $ids, $difficulty, $exercises, $type, $category );
			if ( ! is_wp_error( $result ) ) { return $result; }
			$last_error = $result->get_error_message();
		}

		return new WP_Error( 'citex_ai_quality_failed', sprintf( __( 'Gemini could not produce a fully valid batch after %d quality checks. Nothing was added. Last issue: %s', 'citex-tools' ), self::MAX_QUALITY_ATTEMPTS, $last_error ) );
	}

	/**
	 * The one place that picks which of the 4 (type x category) prompt/schema/
	 * system-instruction sets to use. Adding a third category means adding
	 * one more case here (and the category's own build_prompt and schema
	 * methods) — the request/response handling in generate_questions() above
	 * never changes.
	 */
	private static function build_prompt_for( $type, $category, $ids, $difficulty, $verify, $quality_feedback ) {
		if ( Citex_Reference_Rules::CATEGORY_EDITED_BOOK === $category ) {
			return 'MCQ' === $type
				? self::build_prompt_edited_book_mcq( $ids, $difficulty, $verify, $quality_feedback )
				: self::build_prompt_edited_book( $ids, $difficulty, $verify, $quality_feedback );
		}
		return 'MCQ' === $type
			? self::build_prompt_mcq( $ids, $difficulty, $verify, $quality_feedback )
			: self::build_prompt( $ids, $difficulty, $verify, $quality_feedback );
	}

	private static function schema_for( $type, $category ) {
		if ( Citex_Reference_Rules::CATEGORY_EDITED_BOOK === $category ) {
			return 'MCQ' === $type ? self::schema_edited_book_mcq() : self::schema_edited_book();
		}
		return 'MCQ' === $type ? self::schema_mcq() : self::schema();
	}

	private static function system_instruction_for( $type, $category ) {
		if ( Citex_Reference_Rules::CATEGORY_EDITED_BOOK === $category ) {
			return 'MCQ' === $type
				? 'You are Citex, an academic question-generation engine. Generate real, usable Liverpool Hope University Harvard ReferenceList Edited Book multiple-choice questions, not tests or fictional examples. Verify bibliographic facts when web verification is enabled. Never invent books, editors, years, publishers, or places. Every question must describe exactly ONE canonical bibliographic record with ONE OR MORE editors: editorFullNames (an array of one or two full names), year, bookTitle, place and publisher must all refer to the same real edited book, and the scenario text must explicitly name that same title, every editor\'s full name, the same year, place and publisher — never a different edition or a different book. Citex constructs the single correctly-formatted Harvard reference itself, including the correct editor designation ("(ed.)" for exactly one editor, "(eds)" for two) — you only ever provide THREE plausible but incorrectly-formatted `distractors`, each as {reference, errorReason} naming the SPECIFIC Harvard rule it breaks, never the correct one itself, and never one that swaps "(ed.)"/"(eds)" for the wrong editor count in a way that would make two options simultaneously look correct. Your goal is never "make four references that look different" — it is "one correct reference, three references each with one deliberate, identifiable Harvard error." For every distractor, re-read it end-to-end against the full correct format before returning it: a distractor that is wrong in your head but technically satisfies every Harvard rule when read literally must be rebuilt, since Citex independently re-validates every option and rejects the whole question if more than one is fully valid. CRITICAL — the scenario must state every editor\'s full real name naturally and must NEVER show "(ed.)" or "(eds)" anywhere, must NEVER state, label, or abbreviate any editor\'s initials or surname separately, must NEVER show a completed or abbreviated Harvard citation anywhere, and must NEVER use the words "initial", "initials", or "surname" — the student must recognise the correctly-formatted reference, including its correct editor designation, among the options themselves. Before returning each question, perform a strict self-check: scenario, editorFullNames, year, bookTitle, place and publisher all describe the same book with no contradictions; the scenario reveals no answer value; and all three distractors are clearly wrong (a formatting, punctuation, ordering, or wrong-designation mistake) with a specific errorReason each, mutually distinct from each other, and distinct from the correct reference you did not provide. Return only the requested JSON.'
				: 'You are Citex, an academic question-generation engine. Generate real, usable Liverpool Hope University Harvard ReferenceList Edited Book DragDrop questions, not tests or fictional examples. Verify bibliographic facts when web verification is enabled. Never invent books, editors, years, publishers, or places. Every question must describe exactly ONE canonical bibliographic record with ONE OR MORE editors: editorFullNames (an array of one or two full names), year, bookTitle, place and publisher must all refer to the same real edited book, and the scenario text must explicitly name that same title, every editor\'s full name, the same year, place and publisher — never a different edition or a different book. Citex derives each editor\'s surname and initials itself from editorFullNames, decides the correct editor designation ("(ed.)" for one editor, "(eds)" for two), and constructs Question Parts and Fixed Text itself — you never provide any of that, and your own questionParts/fixedText fields (if you include them) are never read as authoritative. CRITICAL — the scenario must state every editor\'s full name naturally and must NEVER show "(ed.)" or "(eds)" anywhere, must NEVER state, label, or abbreviate any editor\'s initials or surname separately, must NEVER show a completed or abbreviated Harvard citation, and must NEVER use the words "initial", "initials", or "surname". Before returning each question, perform a strict self-check: scenario, editorFullNames, year, bookTitle, place and publisher all describe the same book with no contradictions; the scenario reveals no answer value; and every confusing word is unique and different from every correct value. Return only the requested JSON.';
		}
		return self::system_instruction_for_book( $type );
	}

	private static function system_instruction_for_book( $type ) {
		return 'MCQ' === $type
			? 'You are Citex, an academic question-generation engine. Generate real, usable Liverpool Hope University Harvard ReferenceList Book multiple-choice questions, not tests or fictional examples. Verify bibliographic facts when web verification is enabled. Never invent books, authors, years, publishers, or places. Every question must describe exactly ONE canonical bibliographic record: authorFullName, year, bookTitle, place and publisher must all refer to the same real book, and the scenario text must explicitly name that same title, author, year, place and publisher — never a different edition or a different book. Citex constructs the single correctly-formatted Harvard reference itself from authorFullName/year/bookTitle/place/publisher — you only ever provide THREE plausible but incorrectly-formatted `distractors`, each as {reference, errorReason} naming the SPECIFIC Harvard rule it breaks, never the correct one itself. Your goal is never "make four references that look different" — it is "one correct reference, three references each with one deliberate, identifiable Harvard error." For every distractor, re-read it end-to-end against the full correct format before returning it: a distractor that is wrong in your head but technically satisfies every Harvard rule when read literally must be rebuilt, since Citex independently re-validates every option and rejects the whole question if more than one is fully valid. CRITICAL — the scenario must state the author\'s full real name naturally (for example "Alan Bryman") and must NEVER state, label, or abbreviate the author\'s initials or surname separately, must NEVER show a completed or abbreviated Harvard reference anywhere in the scenario (never write anything like "Bryman, A."), and must NEVER use the words "initial" or "surname" — the student must recognise the correctly-formatted reference among the options themselves, not be handed it in the scenario. Before returning each question, perform a strict self-check: scenario, authorFullName, year, bookTitle, place and publisher all describe the same book with no contradictions; the scenario reveals no answer value; and all three distractors are clearly wrong (a formatting, punctuation, or ordering mistake) with a specific errorReason each, mutually distinct from each other, and distinct from the correct reference you did not provide. Return only the requested JSON.'
			: 'You are Citex, an academic question-generation engine. Generate real, usable Liverpool Hope University Harvard ReferenceList Book DragDrop questions, not tests or fictional examples. Verify bibliographic facts when web verification is enabled. Never invent books, authors, years, publishers, or places. Every question must describe exactly ONE canonical bibliographic record: authorFullName, year, bookTitle, place and publisher must all refer to the same real book, and the scenario text must explicitly name that same title, author, year, place and publisher — never a different edition or a different book. Citex derives the author\'s surname and initials itself from authorFullName — you never provide them separately — and constructs Question Parts and Fixed Text itself from authorFullName/year/bookTitle/place/publisher, so your questionParts and fixedText values are for your own self-check only and are not read as authoritative. CRITICAL — the scenario must state the author\'s full real name naturally (for example "Alan Bryman") and must NEVER state, label, or abbreviate the author\'s initials or surname separately, must NEVER show a completed or abbreviated Harvard reference (never write anything like "Bryman, A."), and must NEVER use the words "initial" or "surname" — the student must derive the initials and the Harvard format themselves from the full name you provide. Before returning each question, perform a strict self-check: scenario, authorFullName, year, bookTitle, place and publisher must all describe the same book with no contradictions; the scenario must not reveal any answer value by labelling it as a surname, initial, year blank, title blank, or reference component; and every confusing word must be unique and different from every correct Question Part. Return only the requested JSON.';
	}

	private static function build_prompt( $ids, $difficulty, $verify, $quality_feedback = '' ) {
		$prompt = "Generate exactly " . count( $ids ) . " distinct Liverpool Hope University Harvard / ReferenceList / Book / DragDrop questions.\nDifficulty: " . ucfirst( $difficulty ) . ".\n" . ( $verify ? 'Use Google Search to verify every bibliographic record.' : 'Do not invent bibliographic records.' ) . "\n\nONE QUESTION = ONE CANONICAL BIBLIOGRAPHIC RECORD — CRITICAL:\n- authorFullName, year, bookTitle, place and publisher must all describe the exact same real book. Do not mix facts from a different edition, a different book by the same author, or a similarly-named book.\n- authorFullName is the author's real full name (given name(s) + surname), e.g. \"Alan Bryman\" or \"John Michael Smith\". Do NOT provide a surname or initials separately — Citex derives both itself from authorFullName.\n- The scenario MUST explicitly state that same bookTitle, the same author's full name, the same year, the same place and the same publisher. Citex independently checks the scenario text against these fields and rejects the question if any of them is not named in the scenario.\n\nSCENARIOS — ANSWER LEAKAGE IS A CRITICAL FAILURE:\n- Keep each scenario short and mobile-friendly, preferably under 220 characters.\n- Use natural wording such as 'You are creating a reference for a book titled...' or 'You are referencing a book titled...'.\n- State the real book title, the author's FULL NAME, publication year, publisher and publication place.\n- Prefer concise real book titles; never truncate or alter the actual bibliographic title.\n- The scenario MUST NOT state, label, or abbreviate the author's initials or surname separately, MUST NOT use the words \"initial\" or \"initials\" or \"surname\" anywhere, and MUST NOT show any completed or abbreviated Harvard reference (e.g. never write \"Bryman, A.\" or \"Bryman, A. (2012)\").\n- GOOD: \"You are referencing the book titled Social Research Methods by Alan Bryman, published in 2012 by Oxford University Press in Oxford.\"\n- BAD: \"...by Alan Bryman (initials A.), published in 2012...\" — reveals the initials directly.\n- BAD: \"...by Bryman, A., published in 2012...\" — states the abbreviated citation form directly.\n- BAD: \"The author's surname is Bryman and his initials are A.\" — explicitly labels both answers.\n- A full author name naturally containing the surname (e.g. \"Alan Bryman\") is correct and required — the failure is explicitly labelling or abbreviating an answer value, not the surname appearing as part of the full name.\n- The student must transform the full bibliographic information you give into the Harvard reference themselves; do not do that transformation for them anywhere in the scenario.\n\nDRAGDROP:\n- Citex derives the author's surname/initials from authorFullName and constructs Question Parts and Fixed Text itself from surname/initials/year/bookTitle/place/publisher — your questionParts and fixedText fields are used only for your own self-check and are not read as authoritative, so make sure they exactly match those fields too (surname = authorFullName's last word; initials = the first letter of every other word in authorFullName, each followed by a full stop, no spaces, e.g. \"John Michael Smith\" -> \"J.M.\").\n- questionParts must contain exactly 4 items: surname, initials, year, book title.\n- fixedText must contain exactly 4 draggable placeholder TOKENS.\n- A single | token is allowed only at the beginning or end. Every internal placeholder token MUST be ||.\n- Canonical fixedText: |, || (||) ||. Place: Publisher.\n- Do not use a single internal |.\n- Reconstructed answer: Surname, I. (YYYY) Book Title. Place: Publisher.\n- No full stop after the year parentheses; no spaces before punctuation; one space after the colon; final full stop required.\n\nDISTRACTORS — CRITICAL:\n- Medium exactly 3; Easy exactly 2; Hard exactly 4.\n- Every distractor must be different from ALL FOUR correct Question Parts after trimming and case-insensitive comparison.\n- Distractors must also be unique from one another.\n- Do not use the correct title, surname, initials, year or any exact copy of a correct part as a distractor.\n- Before returning each question, compare every confusingWords value against all four Question Parts and replace any match.\n- Prefer plausible alternatives such as another year, city, publisher, author surname, or book title.\n\nFINAL SELF-CHECK — DO NOT SKIP:\n1. scenario, authorFullName, year, bookTitle, place and publisher all describe the exact same book — no contradictions.\n2. The scenario states the author's full name naturally and never the words \"initial\"/\"initials\"/\"surname\", and never a completed or abbreviated reference.\n3. Four Question Parts exactly match surname, initials, year, title, correctly derived from authorFullName.\n4. Fixed Text has exactly four placeholder positions and reconstructs the required reference.\n5. No unwanted punctuation or spacing errors.\n6. Correct number of distractors for the difficulty.\n7. Zero distractors match any correct Question Part.\n8. Zero duplicate distractors.\n9. Only return questions that pass all nine checks.\n\nIDs in exact order:\n" . implode( ', ', $ids );
		if ( '' !== trim( $quality_feedback ) ) { $prompt .= "\n\nIMPORTANT — PREVIOUS ATTEMPT FAILED QUALITY CONTROL:\n" . $quality_feedback . "\nRegenerate the affected data and apply the final self-check before returning anything."; }
		return $prompt;
	}

	private static function build_prompt_mcq( $ids, $difficulty, $verify, $quality_feedback = '' ) {
		$difficulty_guidance = array(
			'easy'   => "Easy: the 3 distractors should each contain one obvious, easy-to-spot mistake (e.g. missing punctuation, no parentheses around the year) — testing basic recognition of the Harvard Book structure.",
			'medium' => "Medium: the 3 distractors should each contain one specific, realistic mistake a student could plausibly make (e.g. author's full first name instead of initials, or place/publisher in the wrong order) — testing the ability to spot ONE particular error type per option.",
			'hard'   => "Hard: the 3 distractors should be very close to correctly formatted, differing from the correct one by only a small, easy-to-miss detail (e.g. a single misplaced space, comma, or full stop) — testing careful side-by-side comparison of near-identical references.",
		);
		$prompt = "Generate exactly " . count( $ids ) . " distinct Liverpool Hope University Harvard / ReferenceList / Book multiple-choice questions.\nDifficulty: " . ucfirst( $difficulty ) . ". " . ( $difficulty_guidance[ sanitize_key( $difficulty ) ] ?? $difficulty_guidance['medium'] ) . "\n" . ( $verify ? 'Use Google Search to verify every bibliographic record.' : 'Do not invent bibliographic records.' ) . "\n\nONE QUESTION = ONE CANONICAL BIBLIOGRAPHIC RECORD — CRITICAL:\n- authorFullName, year, bookTitle, place and publisher must all describe the exact same real book. Do not mix facts from a different edition, a different book by the same author, or a similarly-named book.\n- authorFullName is the author's real full name (given name(s) + surname), e.g. \"Alan Bryman\" or \"John Michael Smith\". Do NOT provide a surname or initials separately — Citex derives both itself from authorFullName and constructs the one correct Harvard reference from them; you never provide the correct reference yourself.\n- The scenario MUST explicitly state that same bookTitle, the same author's full name, the same year, the same place and the same publisher. Citex independently checks the scenario text against these fields and rejects the question if any of them is not named in the scenario.\n\nSCENARIOS — ANSWER LEAKAGE IS A CRITICAL FAILURE:\n- Keep each scenario short and mobile-friendly, preferably under 220 characters.\n- Use natural wording such as 'You are creating a reference for a book titled...' or 'You are referencing a book titled...'.\n- State the real book title, the author's FULL NAME, publication year, publisher and publication place.\n- Prefer concise real book titles; never truncate or alter the actual bibliographic title.\n- The scenario MUST NOT state, label, or abbreviate the author's initials or surname separately, MUST NOT use the words \"initial\" or \"initials\" or \"surname\" anywhere, and MUST NOT show any completed or abbreviated Harvard reference anywhere (e.g. never write \"Bryman, A.\" or \"Bryman, A. (2012)\") — this applies even though you are not asked to provide the correct reference yourself, because the correct option Citex constructs must not already be visible in the scenario text.\n- GOOD: \"You are referencing the book titled Social Research Methods by Alan Bryman, published in 2012 by Oxford University Press in Oxford.\"\n- BAD: \"...by Alan Bryman (initials A.), published in 2012...\" — reveals the initials directly.\n- BAD: \"...by Bryman, A., published in 2012...\" — states the abbreviated citation form directly.\n- A full author name naturally containing the surname (e.g. \"Alan Bryman\") is correct and required — the failure is explicitly labelling or abbreviating an answer value, not the surname appearing as part of the full name."
			. self::distractor_prompt_section( Citex_Reference_Rules::CATEGORY_BOOK, 'Surname, I. (YYYY) Book Title. Place: Publisher.' )
			. "\n\nFINAL SELF-CHECK — DO NOT SKIP:\n1. scenario, authorFullName, year, bookTitle, place and publisher all describe the exact same book — no contradictions.\n2. The scenario states the author's full name naturally and never the words \"initial\"/\"initials\"/\"surname\", and never a completed or abbreviated reference.\n3. Exactly 3 distractors are provided, each with a non-empty, specific errorReason naming the Harvard rule it breaks.\n4. Every distractor, re-read end-to-end against the full correct format, genuinely still breaks the rule named in its errorReason — none of them accidentally also satisfies every Harvard rule.\n5. All 3 distractors are mutually distinct from each other and from the correct reference, and exactly one reference overall (the one Citex will construct) is fully correct.\n6. Only return questions that pass all six checks.\n\nIDs in exact order:\n" . implode( ', ', $ids );
		if ( '' !== trim( $quality_feedback ) ) { $prompt .= "\n\nIMPORTANT — PREVIOUS ATTEMPT FAILED QUALITY CONTROL:\n" . $quality_feedback . "\nRegenerate the affected data and apply the final self-check before returning anything."; }
		return $prompt;
	}

	/**
	 * Shared framing for both Edited Book prompt builders: the one-or-two-
	 * editor rule, the "(ed.)"/"(eds)" designation rule, and the answer-
	 * leakage rules — identical whether the question ends up as DragDrop or
	 * MCQ, so written once and reused rather than duplicated.
	 */
	private static function edited_book_prompt_intro( $verify ) {
		return ( $verify ? 'Use Google Search to verify every bibliographic record.' : 'Do not invent bibliographic records.' )
			. "\n\nONE QUESTION = ONE CANONICAL EDITED BOOK RECORD — CRITICAL:\n- editorFullNames is an array of ONE or TWO editor full names (given name(s) + surname each), e.g. [\"Vincent Miller\"] or [\"John Smith\", \"Amy Jones\"]. Do NOT provide a surname or initials separately for any editor — Citex derives both itself from each full name.\n- year, bookTitle, place and publisher must all describe the exact same real edited book as editorFullNames. Do not mix facts from a different edition or a different book.\n- The scenario MUST explicitly state that same bookTitle, EVERY editor's full name, the same year, place and publisher. Citex independently checks the scenario text against these fields.\n\nTHE EDITOR DESIGNATION RULE — THIS IS WHAT THIS CATEGORY TESTS:\n- Exactly ONE editor -> the designation is \"(ed.)\" (with the trailing period, inside its own parentheses).\n- TWO editors -> the designation is \"(eds)\" (no period) and the two editor names are joined with \"and\" (e.g. \"Smith, J. and Jones, A.\").\n- Never use \"(ed.)\" for two editors, and never use \"(eds)\" for one editor.\n- The designation always comes immediately after the editor name(s) and before the year, each in its own parentheses: \"Surname, I. (ed.) (YYYY) Title. Place: Publisher.\"\n\nSCENARIOS — ANSWER LEAKAGE IS A CRITICAL FAILURE:\n- Keep each scenario short and mobile-friendly, preferably under 220 characters.\n- Use natural wording such as 'You are referencing a book edited by...' or 'You are creating a reference for a book edited by...'.\n- State the real book title, EVERY editor's FULL NAME, publication year, publisher and publication place.\n- The scenario MUST NOT show \"(ed.)\" or \"(eds)\" anywhere — that is the answer this question tests.\n- The scenario MUST NOT state, label, or abbreviate any editor's initials or surname separately, MUST NOT use the words \"initial\", \"initials\", or \"surname\" anywhere, and MUST NOT show a completed or abbreviated Harvard citation anywhere (e.g. never write \"Smith, J.\").\n- GOOD: \"You are referencing a book edited by Vincent Miller, titled Understanding digital culture, published in 2020 by SAGE Publications in London.\"\n- BAD: \"...edited by Vincent Miller (ed.), published in 2020...\" — reveals the designation directly.\n- BAD: \"...by Smith, J., published in 2020...\" — states the abbreviated citation form directly.";
	}

	private static function build_prompt_edited_book( $ids, $difficulty, $verify, $quality_feedback = '' ) {
		$difficulty_guidance = array(
			'easy'   => 'Easy: use exactly one editor, and make the confusingWords obviously wrong (e.g. "author", "editor" as a full word, a clearly different year) — testing basic recognition of the "(ed.)" convention.',
			'medium' => 'Medium: mix one-editor and two-editor questions across the batch, and make confusingWords plausible near-misses (e.g. "eds" as a distractor for a one-editor question, or "ed." for a two-editor one) — testing whether the student applies the right designation for the given editor count.',
			'hard'   => 'Hard: prefer two-editor questions, and make confusingWords very close to correct (e.g. "editor" vs "ed.", or "eds." with a stray period) — testing careful attention to exact punctuation.',
		);
		$prompt = "Generate exactly " . count( $ids ) . " distinct Liverpool Hope University Harvard / ReferenceList / Edited Book / DragDrop questions.\nDifficulty: " . ucfirst( $difficulty ) . ". " . ( $difficulty_guidance[ sanitize_key( $difficulty ) ] ?? $difficulty_guidance['medium'] ) . "\n"
			. self::edited_book_prompt_intro( $verify )
			. "\n\nDRAGDROP:\n- Citex derives each editor's surname/initials from editorFullNames, decides the designation (\"(ed.)\"/\"(eds)\") from the editor count, and constructs Question Parts and Fixed Text itself — your own questionParts/fixedText fields (if present) are for your own self-check only and are never read as authoritative.\n- The 4 Question Parts Citex builds are: [editor name(s) joined, e.g. \"Smith, J.\" or \"Smith, J. and Jones, A.\"], [designation, \"ed.\" or \"eds\"], [year], [book title].\n- confusingWords should test the designation and editor-formatting rules specifically — see DISTRACTORS below.\n\nDISTRACTORS — CRITICAL:\n- Medium exactly 3; Easy exactly 2; Hard exactly 4.\n- Prioritise designation-confusion distractors: \"author\", \"editor\" (the full word, not abbreviated), the WRONG designation for this question's editor count (\"eds\" for a one-editor question, \"ed.\" for a two-editor one), or a designation with wrong punctuation (\"ed\", \"eds.\").\n- Also acceptable: a different plausible year, city, publisher, or editor surname.\n- Every distractor must be different from ALL FOUR correct Question Parts after trimming and case-insensitive comparison, and unique from one another.\n\nFINAL SELF-CHECK — DO NOT SKIP:\n1. scenario, editorFullNames, year, bookTitle, place and publisher all describe the exact same book — no contradictions.\n2. The scenario names every editor naturally and never shows \"(ed.)\"/\"(eds)\", never the words \"initial\"/\"initials\"/\"surname\", never a completed citation.\n3. The designation matches the editor count exactly (one editor -> \"ed.\", two -> \"eds\").\n4. Correct number of distractors for the difficulty, none matching a correct Question Part, none duplicated.\n5. Only return questions that pass all four checks.\n\nIDs in exact order:\n" . implode( ', ', $ids );
		if ( '' !== trim( $quality_feedback ) ) { $prompt .= "\n\nIMPORTANT — PREVIOUS ATTEMPT FAILED QUALITY CONTROL:\n" . $quality_feedback . "\nRegenerate the affected data and apply the final self-check before returning anything."; }
		return $prompt;
	}

	private static function build_prompt_edited_book_mcq( $ids, $difficulty, $verify, $quality_feedback = '' ) {
		$difficulty_guidance = array(
			'easy'   => 'Easy: use exactly one editor, and make the 3 distractors obviously wrong (e.g. designation missing entirely, or an unmistakable punctuation error) — testing basic recognition.',
			'medium' => 'Medium: mix one- and two-editor questions, and make each distractor contain one specific, realistic mistake (e.g. "(editor)" instead of "(ed.)", or the wrong designation for the editor count) — testing the ability to spot ONE particular error type per option.',
			'hard'   => 'Hard: prefer two-editor questions, and make the 3 distractors very close to correctly formatted, differing only by a small, easy-to-miss detail (e.g. "(ed.)" used for two editors, or a misplaced comma) — testing careful side-by-side comparison.',
		);
		$prompt = "Generate exactly " . count( $ids ) . " distinct Liverpool Hope University Harvard / ReferenceList / Edited Book multiple-choice questions.\nDifficulty: " . ucfirst( $difficulty ) . ". " . ( $difficulty_guidance[ sanitize_key( $difficulty ) ] ?? $difficulty_guidance['medium'] ) . "\n"
			. self::edited_book_prompt_intro( $verify )
			. self::distractor_prompt_section( Citex_Reference_Rules::CATEGORY_EDITED_BOOK, 'Editor(s), Initials. (ed.|eds) (YYYY) Title. Place: Publisher.' )
			. "\n\nFINAL SELF-CHECK — DO NOT SKIP:\n1. scenario, editorFullNames, year, bookTitle, place and publisher all describe the exact same book — no contradictions.\n2. The scenario names every editor naturally and never shows \"(ed.)\"/\"(eds)\", never the words \"initial\"/\"initials\"/\"surname\", never a completed citation.\n3. Exactly 3 distractors are provided, each with a non-empty, specific errorReason naming the Harvard rule it breaks, especially designation mistakes for this category.\n4. Every distractor, re-read end-to-end against the full correct format, genuinely still breaks the rule named in its errorReason — none of them accidentally also satisfies every Harvard rule (in particular, none accidentally uses the correct \"(ed.)\"/\"(eds)\" designation for this question's editor count).\n5. All 3 distractors are mutually distinct from each other and from the correct reference, and exactly one reference overall (the one Citex will construct) is fully correct.\n6. Only return questions that pass all six checks.\n\nIDs in exact order:\n" . implode( ', ', $ids );
		if ( '' !== trim( $quality_feedback ) ) { $prompt .= "\n\nIMPORTANT — PREVIOUS ATTEMPT FAILED QUALITY CONTROL:\n" . $quality_feedback . "\nRegenerate the affected data and apply the final self-check before returning anything."; }
		return $prompt;
	}

	private static function schema_edited_book() {
		$s = array( 'type' => 'string' );
		return array( 'type' => 'object', 'properties' => array( 'questions' => array( 'type' => 'array', 'items' => array( 'type' => 'object', 'properties' => array(
			'questionId' => $s, 'scenario' => $s, 'editorFullNames' => array( 'type' => 'array', 'items' => $s ), 'year' => $s, 'bookTitle' => $s, 'place' => $s, 'publisher' => $s,
			'questionParts' => array( 'type' => 'array', 'items' => $s ), 'fixedText' => $s, 'confusingWords' => array( 'type' => 'array', 'items' => $s )
		), 'required' => array( 'questionId','scenario','editorFullNames','year','bookTitle','place','publisher','confusingWords' ) ) ) ), 'required' => array( 'questions' ) );
	}

	private static function schema_edited_book_mcq() {
		$s = array( 'type' => 'string' );
		return array( 'type' => 'object', 'properties' => array( 'questions' => array( 'type' => 'array', 'items' => array( 'type' => 'object', 'properties' => array(
			'questionId' => $s, 'scenario' => $s, 'editorFullNames' => array( 'type' => 'array', 'items' => $s ), 'year' => $s, 'bookTitle' => $s, 'place' => $s, 'publisher' => $s,
			'distractors' => self::distractor_schema()
		), 'required' => array( 'questionId','scenario','editorFullNames','year','bookTitle','place','publisher','distractors' ) ) ) ), 'required' => array( 'questions' ) );
	}

	private static function schema() {
		$s = array( 'type' => 'string' );
		return array( 'type' => 'object', 'properties' => array( 'questions' => array( 'type' => 'array', 'items' => array( 'type' => 'object', 'properties' => array(
			'questionId' => $s, 'scenario' => $s, 'authorFullName' => $s, 'year' => $s, 'bookTitle' => $s, 'place' => $s, 'publisher' => $s,
			'questionParts' => array( 'type' => 'array', 'items' => $s ), 'fixedText' => $s, 'confusingWords' => array( 'type' => 'array', 'items' => $s )
		), 'required' => array( 'questionId','scenario','authorFullName','year','bookTitle','place','publisher','questionParts','fixedText','confusingWords' ) ) ) ), 'required' => array( 'questions' ) );
	}

	/**
	 * MCQ schema: Gemini supplies the same canonical bibliographic fields as
	 * DragDrop, plus exactly THREE plausible-but-incorrect Harvard reference
	 * strings — never the correct one. Citex constructs the single correct
	 * option itself (see normalise_mcq_item()), the same "Citex is the sole
	 * authority for the correct answer" principle already used for DragDrop's
	 * Question Parts/Fixed Text.
	 */
	private static function schema_mcq() {
		$s = array( 'type' => 'string' );
		return array( 'type' => 'object', 'properties' => array( 'questions' => array( 'type' => 'array', 'items' => array( 'type' => 'object', 'properties' => array(
			'questionId' => $s, 'scenario' => $s, 'authorFullName' => $s, 'year' => $s, 'bookTitle' => $s, 'place' => $s, 'publisher' => $s,
			'distractors' => self::distractor_schema()
		), 'required' => array( 'questionId','scenario','authorFullName','year','bookTitle','place','publisher','distractors' ) ) ) ), 'required' => array( 'questions' ) );
	}

	/**
	 * Shared shape for one MCQ distractor, used by every category's MCQ
	 * schema: the wrong reference text PLUS the single, specific Harvard
	 * rule it deliberately breaks (errorReason). Forcing Gemini to name the
	 * rule for every distractor — rather than just asking for "a wrong
	 * reference" — is what makes it actually reason about which rule it is
	 * violating instead of inventing a superficially-different reference
	 * that can accidentally still be fully valid (see
	 * normalise_mcq_item()/normalise_edited_book_mcq_item(), which reject
	 * any distractor missing this reason). errorReason is for Citex's own
	 * quality control only — it is never shown to the student and is not
	 * one of the real WordPress ACF fields.
	 */
	private static function distractor_schema() {
		return array(
			'type'  => 'array',
			'items' => array(
				'type'       => 'object',
				'properties' => array(
					'reference'   => array( 'type' => 'string' ),
					'errorReason' => array( 'type' => 'string' ),
				),
				'required' => array( 'reference', 'errorReason' ),
			),
		);
	}

	/**
	 * Shared MCQ distractor instructions for every category: reused by
	 * build_prompt_mcq() (Book) and build_prompt_edited_book_mcq() (Edited
	 * Book), driven by Citex_Reference_Rules::mcq_distractor_patterns( $category )
	 * — the category's own catalogue of named, realistic Harvard mistakes —
	 * so a future category only has to supply its own pattern list and
	 * correct-format description here, never rewrite this instruction text.
	 *
	 * This is the direct fix for MCQ questions being rejected by
	 * MCQ_DISTRACTOR_LOOKS_CORRECT: rather than asking Gemini for "a wrong
	 * reference" and trusting it to have actually made it wrong, this asks
	 * for a SPECIFIC named rule violation per distractor (errorReason) and
	 * makes Gemini re-read each distractor end-to-end against the full
	 * format before returning anything — the same "test the whole option,
	 * not just the intended difference" check Citex's own validator already
	 * performs independently. The two are meant to agree; when Gemini's own
	 * self-check is done properly, Citex's validator has nothing left to
	 * reject.
	 */
	private static function distractor_prompt_section( $category, $correct_format ) {
		$patterns  = Citex_Reference_Rules::mcq_distractor_patterns( $category );
		$catalogue = '';
		foreach ( $patterns as $index => $pattern ) {
			$catalogue .= "\n  " . ( $index + 1 ) . '. ' . $pattern;
		}
		return "\n\nDISTRACTORS — CRITICAL, READ CAREFULLY:\n"
			. "- The goal is NOT \"create four references that look different.\" The goal is \"create ONE correct reference and THREE references that each contain one deliberate, identifiable Harvard error.\"\n"
			. "- Provide exactly 3 entries in `distractors`, each an object: { \"reference\": \"the wrong reference text\", \"errorReason\": \"the specific Harvard rule it breaks\" }. Never provide the correct reference yourself; Citex constructs it.\n"
			. '- Build each distractor by deliberately applying ONE of the following known Harvard error patterns to the correct reference (correct format: ' . $correct_format . ') — do not invent an unrelated kind of mistake:' . $catalogue . "\n"
			. "- errorReason must name the SPECIFIC rule the distractor breaks (e.g. \"Missing the editor designation (ed.)\", \"Places the year after the title instead of after the author\") — never a vague label like \"formatting error\". If you cannot identify a specific rule a distractor breaks, do not include it — regenerate it using a different pattern from the list above instead.\n"
			. "- Before finalising, reason through every option exactly like this, and only return the question once all four checks below pass:\n"
			. "  1. Which reference is correct, and why does it satisfy every Harvard rule?\n"
			. "  2. For each of the 3 distractors: re-read it end-to-end against the FULL correct format (not just the one detail you intended to break) — does it genuinely still violate the rule named in its errorReason, with no other part of it accidentally making it correct again? A distractor that is wrong in your head but technically satisfies every Harvard rule when read literally is NOT a valid distractor and must be rebuilt.\n"
			. "  3. Are all 3 distractors mutually different from each other and from the correct reference?\n"
			. "  4. Is exactly ONE reference overall — the correct one Citex will construct — fully valid? If a second reference (any distractor) would also satisfy every Harvard rule, that is a failure: rebuild that distractor with a different, unambiguous error before returning anything.\n"
			. "- Distractors must still be realistic and plausible — never nonsensical, never an unrelated sentence, never a trivially obvious non-reference (e.g. \"This is not a reference.\"). Every distractor should read like a genuine attempt at the reference with one real student mistake in it.\n"
			. "- Do NOT invent a different author/editor, year, title, place or publisher for a distractor — every distractor must still describe the SAME book as the scenario, just formatted incorrectly.\n"
			. '- None of the 3 distractors may, even coincidentally, already be a fully correctly-formatted reference for this book.';
	}
	/**
	 * Citex — never Gemini — is the sole authority for the author's surname
	 * and initials: both are derived deterministically from authorFullName
	 * rather than asked of Gemini directly, so there is no separate
	 * "initials" value Gemini could leak into the scenario even by mistake.
	 * Initials are every given-name word's first letter, uppercased and
	 * followed by a full stop, concatenated with no spaces (e.g. "John
	 * Michael Smith" -> surname "Smith", initials "J.M.").
	 *
	 * @return array{surname: string, initials: string}|WP_Error
	 */
	private static function derive_author_parts( $full_name ) {
		$full_name = trim( preg_replace( '/\s+/', ' ', (string) $full_name ) );
		$tokens = '' === $full_name ? array() : array_values( array_filter( explode( ' ', $full_name ), 'strlen' ) );
		if ( count( $tokens ) < 2 ) {
			return new WP_Error( 'citex_ai_incomplete_author_name', __( 'Author full name must include at least one given name and a surname.', 'citex-tools' ) );
		}
		$surname = array_pop( $tokens );
		$initials = '';
		foreach ( $tokens as $given_name ) {
			$letter = mb_substr( $given_name, 0, 1 );
			if ( '' === $letter ) {
				continue;
			}
			$initials .= mb_strtoupper( $letter ) . '.';
		}
		if ( '' === $initials ) {
			return new WP_Error( 'citex_ai_incomplete_author_name', __( 'Author full name must include at least one given name and a surname.', 'citex-tools' ) );
		}
		return array( 'surname' => $surname, 'initials' => $initials );
	}
	private static function build_ids( $start, $quantity, $used_ids ) {
		if ( ! preg_match( '/^([A-Z]+)(\d+)$/', $start, $m ) ) { return new WP_Error( 'citex_ai_bad_start_id', __( 'Starting ID must look like BK01, BK25, or BOOK001.', 'citex-tools' ) ); }
		$prefix = $m[1]; $number = absint( $m[2] ); $width = max( 2, strlen( $m[2] ) ); $used = array(); foreach ( $used_ids as $id ) { $used[ strtoupper( trim( (string) $id ) ) ] = true; }
		$out = array(); while ( count( $out ) < $quantity ) { $id = $prefix . str_pad( (string) $number++, $width, '0', STR_PAD_LEFT ); if ( isset( $used[ $id ] ) ) { continue; } $used[ $id ] = true; $out[] = $id; } return $out;
	}
	private static function placeholder_count( $fixed ) {
		$count = 0; $len = strlen( $fixed );
		for ( $i = 0; $i < $len; ) {
			if ( '|' !== $fixed[ $i ] ) { $i++; continue; }
			if ( $i + 1 < $len && '|' === $fixed[ $i + 1 ] ) { $count++; $i += 2; continue; }
			$before = substr( $fixed, 0, $i ); $after = substr( $fixed, $i + 1 );
			$is_first = '' === trim( $before ); $is_final = 1 === preg_match( '/^[\s\.,;:!?\-–—]*$/u', $after );
			if ( ! $is_first && ! $is_final ) { return new WP_Error( 'citex_ai_bad_placeholder_encoding', 'A single internal | is not allowed; internal draggable placeholders must use ||.' ); }
			$count++; $i++;
		}
		return $count;
	}
	private static function expected_distractor_count( $difficulty ) {
		switch ( sanitize_key( $difficulty ) ) {
			case 'easy': return 2;
			case 'hard': return 4;
			default: return 3;
		}
	}
	private static function normalise( $questions, $ids, $difficulty, $exercises = array(), $type = 'DragDrop', $category = null ) {
		$category = $category ?: Citex_Reference_Rules::CATEGORY_BOOK;
		$out = array();
		$expected_distractors = self::expected_distractor_count( $difficulty );
		foreach ( $questions as $i => $item ) {
			if ( ! is_array( $item ) ) { return new WP_Error( 'citex_ai_bad_question', sprintf( __( 'Question %d was not a valid object.', 'citex-tools' ), $i + 1 ) ); }
			$id = strtoupper( trim( (string) $ids[ $i ] ) ); $year = trim( (string) ( $item['year'] ?? '' ) ); $title = trim( (string) ( $item['bookTitle'] ?? '' ) ); $place = trim( (string) ( $item['place'] ?? '' ) ); $publisher = trim( (string) ( $item['publisher'] ?? '' ) ); $scenario = trim( (string) ( $item['scenario'] ?? '' ) );

			// Exercise is Citex-assigned only — resolved by slot index from the
			// matrix built before generation began, never read from $item.
			$exercise = isset( $exercises[ $i ] ) ? sanitize_text_field( (string) $exercises[ $i ] ) : 'Exercise 1';

			if ( Citex_Reference_Rules::CATEGORY_EDITED_BOOK === $category ) {
				if ( '' === $scenario || '' === $year || '' === $title || '' === $place || '' === $publisher ) { return new WP_Error( 'citex_ai_missing_field', sprintf( __( 'Question %s is missing required bibliographic data.', 'citex-tools' ), $id ) ); }
				$editor_names = array_values( array_filter( array_map( 'trim', (array) ( $item['editorFullNames'] ?? array() ) ), 'strlen' ) );
				if ( empty( $editor_names ) || count( $editor_names ) > 2 ) { return new WP_Error( 'citex_ai_bad_editor_count', sprintf( __( 'Question %s must have 1 or 2 editors; %d were provided.', 'citex-tools' ), $id, count( $editor_names ) ) ); }
				$editors = array();
				foreach ( $editor_names as $editor_full_name ) {
					$editor_parts = self::derive_author_parts( $editor_full_name );
					if ( is_wp_error( $editor_parts ) ) { return new WP_Error( 'citex_ai_missing_field', sprintf( __( 'Question %1$s: %2$s', 'citex-tools' ), $id, $editor_parts->get_error_message() ) ); }
					$editors[] = array( 'fullName' => $editor_full_name, 'surname' => $editor_parts['surname'], 'initials' => $editor_parts['initials'] );
				}
				$candidate = 'MCQ' === $type
					? self::normalise_edited_book_mcq_item( $item, $id, $editors, $year, $title, $place, $publisher, $scenario, $exercise, $difficulty )
					: self::normalise_edited_book_item( $item, $id, $editors, $year, $title, $place, $publisher, $scenario, $exercise, $difficulty, $expected_distractors );
			} else {
				$full_name = trim( (string) ( $item['authorFullName'] ?? '' ) );
				if ( '' === $scenario || '' === $full_name || '' === $year || '' === $title || '' === $place || '' === $publisher ) { return new WP_Error( 'citex_ai_missing_field', sprintf( __( 'Question %s is missing required bibliographic data.', 'citex-tools' ), $id ) ); }

				$author_parts = self::derive_author_parts( $full_name );
				if ( is_wp_error( $author_parts ) ) { return new WP_Error( 'citex_ai_missing_field', sprintf( __( 'Question %1$s: %2$s', 'citex-tools' ), $id, $author_parts->get_error_message() ) ); }
				$surname = $author_parts['surname'];
				$initials = $author_parts['initials'];

				$candidate = 'MCQ' === $type
					? self::normalise_mcq_item( $item, $id, $full_name, $surname, $initials, $year, $title, $place, $publisher, $scenario, $exercise, $difficulty )
					: self::normalise_dragdrop_item( $item, $id, $full_name, $surname, $initials, $year, $title, $place, $publisher, $scenario, $exercise, $difficulty, $expected_distractors );
			}
			if ( is_wp_error( $candidate ) ) { return $candidate; }

			$validation = Citex_Generated_Validator::validate( $candidate );
			if ( 'passed' !== $validation['status'] ) { $first_error = ! empty( $validation['errors'][0]['message'] ) ? $validation['errors'][0]['message'] : __( 'Generated question failed Citex validation.', 'citex-tools' ); return new WP_Error( 'citex_ai_validator_rejected', sprintf( __( 'Question %s failed the pre-queue quality gate: %s', 'citex-tools' ), $id, $first_error ) ); }
			$candidate['validatedReference'] = $validation['reconstructedReference'];
			$candidate['validationStatus'] = 'passed';
			$candidate['validationErrors'] = array();
			$candidate['validatedAt'] = $validation['validatedAt'];
			$out[] = $candidate;
		}
		return $out;
	}

	/**
	 * Citex — not Gemini — is the sole author of Question Parts and Fixed
	 * Text. Both are built here directly from the canonical bibliographic
	 * record (authorSurname/authorInitials/year/bookTitle/place/publisher)
	 * instead of trusting Gemini's own questionParts/fixedText output.
	 * Gemini's own fields could previously agree with each other while the
	 * separately-written scenario described a different book entirely —
	 * constructing Question Parts and Fixed Text here makes that
	 * structurally impossible instead of merely self-consistent.
	 *
	 * @return array|WP_Error
	 */
	private static function normalise_dragdrop_item( $item, $id, $full_name, $surname, $initials, $year, $title, $place, $publisher, $scenario, $exercise, $difficulty, $expected_distractors ) {
		$distractors = array_values( array_filter( array_map( 'trim', (array) ( $item['confusingWords'] ?? array() ) ), 'strlen' ) );
		$parts = array( $surname, $initials, $year, $title );
		$fixed = sprintf( '|, || (||) ||. %s: %s.', $place, $publisher );
		$count = self::placeholder_count( $fixed ); if ( is_wp_error( $count ) ) { return $count; } if ( 4 !== $count ) { return new WP_Error( 'citex_ai_bad_placeholders', sprintf( __( 'Question %s has %d draggable placeholder tokens; exactly 4 are required.', 'citex-tools' ), $id, $count ) ); }
		if ( count( $distractors ) !== $expected_distractors ) { return new WP_Error( 'citex_ai_bad_distractors', sprintf( __( 'Question %s has %d distractors; %d are required for %s difficulty.', 'citex-tools' ), $id, count( $distractors ), $expected_distractors, ucfirst( $difficulty ) ) ); }
		$correct_lower = array_map( 'strtolower', array_map( 'trim', $parts ) ); $seen = array();
		foreach ( $distractors as $distractor ) {
			$normal = strtolower( trim( $distractor ) );
			if ( in_array( $normal, $correct_lower, true ) ) { return new WP_Error( 'citex_ai_distractor_matches_part', sprintf( __( 'Question %s has a distractor that duplicates a correct Question Part: %s.', 'citex-tools' ), $id, $distractor ) ); }
			if ( isset( $seen[ $normal ] ) ) { return new WP_Error( 'citex_ai_duplicate_distractor', sprintf( __( 'Question %s has a duplicate distractor: %s.', 'citex-tools' ), $id, $distractor ) ); }
			$seen[ $normal ] = true;
		}
		$reference = sprintf( '%s, %s (%s) %s. %s: %s.', $surname, $initials, $year, $title, $place, $publisher );
		return array( 'key' => wp_generate_uuid4(), 'questionId' => $id, 'title' => sprintf( 'Harvard | ReferenceList | Book | DragDrop | %s', $id ), 'source' => 'Harvard', 'group' => 'ReferenceList', 'category' => 'Book', 'exercise' => $exercise, 'type' => 'DragDrop', 'institution' => 'Liverpool Hope University', 'difficulty' => ucfirst( $difficulty ), 'scenario' => sanitize_textarea_field( $scenario ), 'authorFullName' => sanitize_text_field( $full_name ), 'authorSurname' => sanitize_text_field( $surname ), 'authorInitials' => sanitize_text_field( $initials ), 'year' => sanitize_text_field( $year ), 'bookTitle' => sanitize_text_field( $title ), 'place' => sanitize_text_field( $place ), 'publisher' => sanitize_text_field( $publisher ), 'fixedText' => sanitize_text_field( $fixed ), 'questionParts' => array_values( array_map( 'sanitize_text_field', $parts ) ), 'confusingWords' => array_values( array_map( 'sanitize_text_field', $distractors ) ), 'reconstructedReference' => sanitize_text_field( $reference ), 'status' => 'pending', 'validationStatus' => 'not_validated', 'validationErrors' => array(), 'origin' => 'generated_ai', 'aiProvider' => 'Gemini', 'aiModel' => self::get_model(), 'generatedAt' => gmdate( 'c' ) );
	}

	/**
	 * Citex — not Gemini — constructs the single correctly-formatted Harvard
	 * reference (the same construction used for DragDrop's
	 * reconstructedReference) and is the sole authority for which of the 4
	 * options is correct. Gemini only ever supplies THREE incorrect options;
	 * it never sees or chooses the correct one, so there is no correct-answer
	 * value for it to leak or place predictably.
	 *
	 * The correct option's position (0-3) is derived deterministically from
	 * the question ID (crc32) rather than true randomness — this still
	 * varies unpredictably per question (never a fixed slot a student could
	 * learn to exploit) while keeping generation and its tests deterministic.
	 *
	 * @return array|WP_Error
	 */
	private static function normalise_mcq_item( $item, $id, $full_name, $surname, $initials, $year, $title, $place, $publisher, $scenario, $exercise, $difficulty ) {
		$distractors = self::extract_mcq_distractors( $item, $id );
		if ( is_wp_error( $distractors ) ) {
			return $distractors;
		}
		$incorrect = array_column( $distractors, 'reference' );

		$reference = sprintf( '%s, %s (%s) %s. %s: %s.', $surname, $initials, $year, $title, $place, $publisher );
		$correct_normal = strtolower( trim( preg_replace( '/\s+/', ' ', $reference ) ) );
		$seen = array( $correct_normal => true );
		foreach ( $incorrect as $option ) {
			$normal = strtolower( trim( preg_replace( '/\s+/', ' ', $option ) ) );
			if ( $normal === $correct_normal ) {
				return new WP_Error( 'citex_ai_mcq_option_matches_correct', sprintf( __( 'Question %s has an "incorrect" reference option identical to the correct one.', 'citex-tools' ), $id ) );
			}
			if ( isset( $seen[ $normal ] ) ) {
				return new WP_Error( 'citex_ai_mcq_duplicate_option', sprintf( __( 'Question %s has a duplicate incorrect reference option.', 'citex-tools' ), $id ) );
			}
			$seen[ $normal ] = true;
		}

		list( $options, $option_reasons, $correct_index ) = self::place_mcq_options( $id, $reference, $distractors );
		// A-D letter, matching the position options actually land in — never
		// a fixed letter, since correct_index itself varies per question.
		$correct_letter = chr( 65 + $correct_index );

		// Citex — not Gemini — writes the explanation too, deterministically
		// from the same canonical record, rather than trusting free-form
		// prose from Gemini to always be accurate. This is the real site's
		// "Hint" field content (there is no separate "explanation" field —
		// see class-citex-populator.php's FIELD_HINT), shown to the student
		// only after they submit an answer.
		$explanation = sprintf(
			'%1$s is correct because it follows the required Harvard reference structure: Surname, Initials. (Year) Title. Place: Publisher.',
			$correct_letter
		);

		return array( 'key' => wp_generate_uuid4(), 'questionId' => $id, 'title' => sprintf( 'Harvard | ReferenceList | Book | MCQ | %s', $id ), 'source' => 'Harvard', 'group' => 'ReferenceList', 'category' => 'Book', 'exercise' => $exercise, 'type' => 'MCQ', 'institution' => 'Liverpool Hope University', 'difficulty' => ucfirst( $difficulty ), 'scenario' => sanitize_textarea_field( $scenario ), 'authorFullName' => sanitize_text_field( $full_name ), 'authorSurname' => sanitize_text_field( $surname ), 'authorInitials' => sanitize_text_field( $initials ), 'year' => sanitize_text_field( $year ), 'bookTitle' => sanitize_text_field( $title ), 'place' => sanitize_text_field( $place ), 'publisher' => sanitize_text_field( $publisher ), 'options' => array_values( array_map( 'sanitize_text_field', $options ) ), 'optionErrorReasons' => $option_reasons, 'correctOptionIndex' => $correct_index, 'correctOptionLetter' => $correct_letter, 'explanation' => sanitize_textarea_field( $explanation ), 'reconstructedReference' => sanitize_text_field( $reference ), 'status' => 'pending', 'validationStatus' => 'not_validated', 'validationErrors' => array(), 'origin' => 'generated_ai', 'aiProvider' => 'Gemini', 'aiModel' => self::get_model(), 'generatedAt' => gmdate( 'c' ) );
	}

	/**
	 * Extracts and validates the 3 {reference, errorReason} distractor
	 * objects Gemini supplies for one MCQ item (see distractor_schema()) —
	 * shared by every category's normalise_*_mcq_item(), so a future
	 * category's MCQ item builder gets this structural gate for free.
	 *
	 * A distractor missing a specific, non-empty errorReason is rejected
	 * here — same as any other WP_Error returned during normalise(), this
	 * fails the whole batch's quality gate and triggers Citex_AI_V2's
	 * existing regenerate-with-feedback retry loop (see
	 * generate_questions()) rather than silently accepting an unreasoned
	 * distractor. Per the "if an incorrect option cannot be given a
	 * specific valid error reason, reject and regenerate" requirement, this
	 * is a pure presence/non-emptiness check — it cannot itself verify the
	 * reason is accurate, but Citex_Generated_Validator::validate_mcq()'s
	 * existing MCQ_DISTRACTOR_LOOKS_CORRECT check (every non-correct option
	 * re-run through the real Harvard format rules) remains the actual
	 * authority on whether a distractor is genuinely wrong — this check
	 * only makes Gemini commit to a specific claim it can be judged against.
	 *
	 * @return array|WP_Error array of ['reference' => string, 'errorReason' => string], always exactly 3
	 */
	private static function extract_mcq_distractors( $item, $id ) {
		$raw = is_array( $item['distractors'] ?? null ) ? array_values( $item['distractors'] ) : array();
		if ( 3 !== count( $raw ) ) {
			return new WP_Error( 'citex_ai_bad_mcq_options', sprintf( __( 'Question %1$s has %2$d distractor(s); exactly 3 are required.', 'citex-tools' ), $id, count( $raw ) ) );
		}
		$distractors = array();
		foreach ( $raw as $index => $entry ) {
			$reference = is_array( $entry ) ? trim( (string) ( $entry['reference'] ?? '' ) ) : '';
			$reason    = is_array( $entry ) ? trim( (string) ( $entry['errorReason'] ?? '' ) ) : '';
			if ( '' === $reference ) {
				return new WP_Error( 'citex_ai_mcq_distractor_missing_reference', sprintf( __( 'Question %1$s distractor %2$d is missing its reference text.', 'citex-tools' ), $id, $index + 1 ) );
			}
			if ( '' === $reason ) {
				return new WP_Error( 'citex_ai_mcq_distractor_reason_missing', sprintf( __( 'Question %1$s distractor %2$d ("%3$s") has no specific errorReason — every incorrect option must name the Harvard rule it breaks.', 'citex-tools' ), $id, $index + 1, $reference ) );
			}
			$distractors[] = array( 'reference' => $reference, 'errorReason' => $reason );
		}
		return $distractors;
	}

	/**
	 * Places the correct reference and the 3 {reference, errorReason}
	 * distractors into the 4 option slots, at the same crc32(question ID)
	 * derived position used since MCQ was first introduced — shared by
	 * every category's normalise_*_mcq_item() so the placement rule (and
	 * its determinism, for tests) lives in exactly one place.
	 *
	 * @return array{0: string[], 1: array<string|null>, 2: int} [options, optionErrorReasons (null at the correct slot), correctOptionIndex]
	 */
	private static function place_mcq_options( $id, $reference, $distractors ) {
		$correct_index = crc32( $id ) % 4;
		$options = array();
		$reasons = array();
		$cursor  = 0;
		for ( $slot = 0; $slot < 4; $slot++ ) {
			if ( $slot === $correct_index ) {
				$options[] = $reference;
				$reasons[] = null;
			} else {
				$options[] = $distractors[ $cursor ]['reference'];
				$reasons[] = sanitize_text_field( $distractors[ $cursor ]['errorReason'] );
				$cursor++;
			}
		}
		return array( $options, $reasons, $correct_index );
	}

	/**
	 * Edited Book counterpart to normalise_dragdrop_item(). Citex — never
	 * Gemini — builds the reference, the editor designation ("(ed.)" for
	 * one editor, "(eds)" for two), and the Question Parts/Fixed Text, via
	 * Citex_Reference_Rules::build_reference()/dragdrop_shape() — the same
	 * pluggable layer that also drives Citex_Generated_Validator, so the
	 * two can never silently disagree about what "correct" looks like for
	 * this category.
	 *
	 * @return array|WP_Error
	 */
	private static function normalise_edited_book_item( $item, $id, $editors, $year, $title, $place, $publisher, $scenario, $exercise, $difficulty, $expected_distractors ) {
		$distractors = array_values( array_filter( array_map( 'trim', (array) ( $item['confusingWords'] ?? array() ) ), 'strlen' ) );
		$fields = array( 'editors' => $editors, 'year' => $year, 'title' => $title, 'place' => $place, 'publisher' => $publisher );
		$shape = Citex_Reference_Rules::dragdrop_shape( Citex_Reference_Rules::CATEGORY_EDITED_BOOK, $fields );
		$parts = $shape['parts'];
		$fixed = $shape['fixedText'];
		$count = self::placeholder_count( $fixed ); if ( is_wp_error( $count ) ) { return $count; } if ( 4 !== $count ) { return new WP_Error( 'citex_ai_bad_placeholders', sprintf( __( 'Question %s has %d draggable placeholder tokens; exactly 4 are required.', 'citex-tools' ), $id, $count ) ); }
		if ( count( $distractors ) !== $expected_distractors ) { return new WP_Error( 'citex_ai_bad_distractors', sprintf( __( 'Question %s has %d distractors; %d are required for %s difficulty.', 'citex-tools' ), $id, count( $distractors ), $expected_distractors, ucfirst( $difficulty ) ) ); }
		$correct_lower = array_map( 'strtolower', array_map( 'trim', $parts ) ); $seen = array();
		foreach ( $distractors as $distractor ) {
			$normal = strtolower( trim( $distractor ) );
			if ( in_array( $normal, $correct_lower, true ) ) { return new WP_Error( 'citex_ai_distractor_matches_part', sprintf( __( 'Question %s has a distractor that duplicates a correct Question Part: %s.', 'citex-tools' ), $id, $distractor ) ); }
			if ( isset( $seen[ $normal ] ) ) { return new WP_Error( 'citex_ai_duplicate_distractor', sprintf( __( 'Question %s has a duplicate distractor: %s.', 'citex-tools' ), $id, $distractor ) ); }
			$seen[ $normal ] = true;
		}
		$reference = Citex_Reference_Rules::build_reference( Citex_Reference_Rules::CATEGORY_EDITED_BOOK, $fields );
		$editor_full_names = array_column( $editors, 'fullName' );
		return array( 'key' => wp_generate_uuid4(), 'questionId' => $id, 'title' => sprintf( 'Harvard | ReferenceList | Edited Book | DragDrop | %s', $id ), 'source' => 'Harvard', 'group' => 'ReferenceList', 'category' => 'Edited Book', 'exercise' => $exercise, 'type' => 'DragDrop', 'institution' => 'Liverpool Hope University', 'difficulty' => ucfirst( $difficulty ), 'scenario' => sanitize_textarea_field( $scenario ), 'editors' => array_map( function ( $editor ) { return array( 'fullName' => sanitize_text_field( $editor['fullName'] ), 'surname' => sanitize_text_field( $editor['surname'] ), 'initials' => sanitize_text_field( $editor['initials'] ) ); }, $editors ), 'editorFullNames' => array_values( array_map( 'sanitize_text_field', $editor_full_names ) ), 'year' => sanitize_text_field( $year ), 'bookTitle' => sanitize_text_field( $title ), 'place' => sanitize_text_field( $place ), 'publisher' => sanitize_text_field( $publisher ), 'fixedText' => sanitize_text_field( $fixed ), 'questionParts' => array_values( array_map( 'sanitize_text_field', $parts ) ), 'confusingWords' => array_values( array_map( 'sanitize_text_field', $distractors ) ), 'reconstructedReference' => sanitize_text_field( $reference ), 'status' => 'pending', 'validationStatus' => 'not_validated', 'validationErrors' => array(), 'origin' => 'generated_ai', 'aiProvider' => 'Gemini', 'aiModel' => self::get_model(), 'generatedAt' => gmdate( 'c' ) );
	}

	/**
	 * Edited Book counterpart to normalise_mcq_item(): same "Citex builds
	 * the one correct option, Gemini only ever supplies 3 incorrect ones"
	 * principle, using Citex_Reference_Rules::build_reference() so the
	 * correct option always carries the right "(ed.)"/"(eds)" designation
	 * for this question's actual editor count.
	 *
	 * @return array|WP_Error
	 */
	private static function normalise_edited_book_mcq_item( $item, $id, $editors, $year, $title, $place, $publisher, $scenario, $exercise, $difficulty ) {
		$distractors = self::extract_mcq_distractors( $item, $id );
		if ( is_wp_error( $distractors ) ) {
			return $distractors;
		}
		$incorrect = array_column( $distractors, 'reference' );

		$fields = array( 'editors' => $editors, 'year' => $year, 'title' => $title, 'place' => $place, 'publisher' => $publisher );
		$reference = Citex_Reference_Rules::build_reference( Citex_Reference_Rules::CATEGORY_EDITED_BOOK, $fields );
		$correct_normal = strtolower( trim( preg_replace( '/\s+/', ' ', $reference ) ) );
		$seen = array( $correct_normal => true );
		foreach ( $incorrect as $option ) {
			$normal = strtolower( trim( preg_replace( '/\s+/', ' ', $option ) ) );
			if ( $normal === $correct_normal ) {
				return new WP_Error( 'citex_ai_mcq_option_matches_correct', sprintf( __( 'Question %s has an "incorrect" reference option identical to the correct one.', 'citex-tools' ), $id ) );
			}
			if ( isset( $seen[ $normal ] ) ) {
				return new WP_Error( 'citex_ai_mcq_duplicate_option', sprintf( __( 'Question %s has a duplicate incorrect reference option.', 'citex-tools' ), $id ) );
			}
			$seen[ $normal ] = true;
		}

		list( $options, $option_reasons, $correct_index ) = self::place_mcq_options( $id, $reference, $distractors );
		$correct_letter = chr( 65 + $correct_index );

		$expected_designation = Citex_Reference_Rules::designation_for_editor_count( count( $editors ) );
		$explanation = sprintf(
			'%1$s is correct because it follows the required Harvard Edited Book reference structure — Editor(s), Initials. (%2$s) (Year) Title. Place: Publisher — using "(%2$s)" for %3$d editor(s).',
			$correct_letter,
			$expected_designation,
			count( $editors )
		);

		$editor_full_names = array_column( $editors, 'fullName' );
		return array( 'key' => wp_generate_uuid4(), 'questionId' => $id, 'title' => sprintf( 'Harvard | ReferenceList | Edited Book | MCQ | %s', $id ), 'source' => 'Harvard', 'group' => 'ReferenceList', 'category' => 'Edited Book', 'exercise' => $exercise, 'type' => 'MCQ', 'institution' => 'Liverpool Hope University', 'difficulty' => ucfirst( $difficulty ), 'scenario' => sanitize_textarea_field( $scenario ), 'editors' => array_map( function ( $editor ) { return array( 'fullName' => sanitize_text_field( $editor['fullName'] ), 'surname' => sanitize_text_field( $editor['surname'] ), 'initials' => sanitize_text_field( $editor['initials'] ) ); }, $editors ), 'editorFullNames' => array_values( array_map( 'sanitize_text_field', $editor_full_names ) ), 'year' => sanitize_text_field( $year ), 'bookTitle' => sanitize_text_field( $title ), 'place' => sanitize_text_field( $place ), 'publisher' => sanitize_text_field( $publisher ), 'options' => array_values( array_map( 'sanitize_text_field', $options ) ), 'optionErrorReasons' => $option_reasons, 'correctOptionIndex' => $correct_index, 'correctOptionLetter' => $correct_letter, 'explanation' => sanitize_textarea_field( $explanation ), 'reconstructedReference' => sanitize_text_field( $reference ), 'status' => 'pending', 'validationStatus' => 'not_validated', 'validationErrors' => array(), 'origin' => 'generated_ai', 'aiProvider' => 'Gemini', 'aiModel' => self::get_model(), 'generatedAt' => gmdate( 'c' ) );
	}

	private static function output_text( $data ) {
		if ( ! empty( $data['output_text'] ) && is_string( $data['output_text'] ) ) { return trim( $data['output_text'] ); }
		$text = array(); foreach ( (array) ( $data['steps'] ?? array() ) as $step ) { if ( 'model_output' !== ( $step['type'] ?? '' ) ) { continue; } foreach ( (array) ( $step['content'] ?? array() ) as $content ) { if ( isset( $content['text'] ) && is_string( $content['text'] ) ) { $text[] = $content['text']; } } } return trim( implode( "\n", $text ) );
	}
	private static function strip_fences( $text ) { $text = trim( $text ); $text = preg_replace( '/^```(?:json)?\s*/i', '', $text ); $text = preg_replace( '/\s*```$/', '', $text ); return trim( $text ); }
}
