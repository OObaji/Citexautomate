<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Validates generated Citex records before they are allowed to populate the
 * real WordPress Reference List.
 *
 * This deliberately validates the generated structured data directly rather
 * than pretending it is already a WordPress post. The rules mirror the Book /
 * DragDrop checks used by the live validator: placeholder reconstruction,
 * year punctuation/spacing, punctuation spacing, colon spacing, final full
 * stop, Book shape, and distractor separation.
 */
class Citex_Generated_Validator {

	/**
	 * Validate one pending generated question.
	 *
	 * @param array $question Pending generator record.
	 * @return array Structured result.
	 */
	public static function validate( $question ) {
		if (
			'Harvard' !== (string) ( $question['source'] ?? '' ) ||
			'ReferenceList' !== (string) ( $question['group'] ?? '' ) ||
			! Citex_Reference_Rules::is_known_category( (string) ( $question['category'] ?? '' ) )
		) {
			return self::result(
				'failed',
				array(
					self::error( 'UNSUPPORTED_GENERATED_FORMAT', 'Generated validation currently supports only Harvard / ReferenceList / Book or Edited Book, DragDrop or MCQ.' ),
				),
				null
			);
		}

		$type = (string) ( $question['type'] ?? '' );
		if ( 'DragDrop' === $type ) {
			return self::validate_dragdrop( $question );
		}
		if ( 'MCQ' === $type ) {
			return self::validate_mcq( $question );
		}

		return self::result(
			'failed',
			array(
				self::error( 'UNSUPPORTED_GENERATED_FORMAT', 'Generated validation currently supports only Harvard / ReferenceList / Book / DragDrop or MCQ.' ),
			),
			null
		);
	}

	private static function validate_dragdrop( $question ) {
		$errors   = array();
		$category = (string) ( $question['category'] ?? Citex_Reference_Rules::CATEGORY_BOOK );

		$fixed_text     = (string) ( $question['fixedText'] ?? '' );
		$question_parts = is_array( $question['questionParts'] ?? null ) ? array_values( $question['questionParts'] ) : array();
		$confusing      = is_array( $question['confusingWords'] ?? null ) ? array_values( $question['confusingWords'] ) : array();

		if ( '' === trim( $fixed_text ) ) {
			$errors[] = self::error( 'FIXED_TEXT_MISSING', 'Fixed Text is missing.' );
		}
		if ( empty( $question_parts ) ) {
			$errors[] = self::error( 'QUESTION_PARTS_MISSING', 'Question Parts are missing.' );
		}

		$reconstruction = self::reconstruct( $fixed_text, $question_parts );
		if ( is_wp_error( $reconstruction ) ) {
			$errors[] = self::error( $reconstruction->get_error_code(), $reconstruction->get_error_message() );
			return self::result( 'failed', $errors, null );
		}

		$reference = $reconstruction['reference'];
		$errors    = array_merge( $errors, self::validate_reference_format( $reference, $category, $question['place'] ?? null, $question['publisher'] ?? null, self::expected_designation_for( $question, $category ), self::expected_editor_join_for( $question, $category ) ) );

		$correct_lower = array_map(
			function ( $value ) {
				return strtolower( trim( (string) $value ) );
			},
			$question_parts
		);
		$seen_confusing = array();
		foreach ( $confusing as $word ) {
			$normal = strtolower( trim( (string) $word ) );
			if ( '' === $normal ) {
				continue;
			}
			if ( in_array( $normal, $correct_lower, true ) ) {
				$errors[] = self::error( 'DISTRACTOR_MATCHES_CORRECT_PART', 'A confusing word duplicates a correct draggable Question Part: ' . (string) $word );
			}
			if ( isset( $seen_confusing[ $normal ] ) ) {
				$errors[] = self::error( 'DUPLICATE_DISTRACTOR', 'A confusing word is duplicated: ' . (string) $word );
			}
			$seen_confusing[ $normal ] = true;
		}

		$expected = trim( (string) ( $question['reconstructedReference'] ?? '' ) );
		if ( '' !== $expected && $expected !== $reference ) {
			$errors[] = self::error( 'RECONSTRUCTED_REFERENCE_MISMATCH', 'The generated expected reference does not match the reference reconstructed from Fixed Text and Question Parts.' );
		}

		$errors = array_merge( $errors, self::validate_consistency( $question, $question_parts, $reference, $category ) );
		$errors = array_merge( $errors, self::validate_answer_leakage( $question ) );

		return self::result( empty( $errors ) ? 'passed' : 'failed', $errors, $reference );
	}

	/**
	 * Dispatches to the category-appropriate bibliographic-consistency
	 * check — Book has a single author, Edited Book has one or more
	 * editors, so the two need different field shapes (see
	 * validate_edited_book_consistency()). Every other category-specific
	 * difference (format regex, DragDrop piece construction) is already
	 * isolated to Citex_Reference_Rules; this is the one check that could
	 * not be made category-agnostic, because "who wrote this" is shaped
	 * differently per category.
	 *
	 * $check_scenario defaults to true — DragDrop's scenario still must
	 * describe the specific book (unchanged). MCQ passes false: its
	 * question text is now Citex's own fixed, category-generic stem (see
	 * Citex_Reference_Rules::mcq_question_stem()), which deliberately never
	 * mentions the book's title/author/year/etc, so that portion of the
	 * consistency check does not apply to it — the reference-must-contain-
	 * the-facts checks (1-10 in validate_bibliographic_consistency(), the
	 * equivalent block in validate_edited_book_consistency()) still run for
	 * MCQ exactly as before; only the scenario-text block is skipped.
	 */
	private static function validate_consistency( $question, $question_parts, $reference, $category, $check_scenario = true ) {
		if ( Citex_Reference_Rules::CATEGORY_EDITED_BOOK === $category ) {
			return self::validate_edited_book_consistency( $question, $reference, $check_scenario );
		}
		return self::validate_bibliographic_consistency( $question, $question_parts, $reference, $check_scenario );
	}

	/**
	 * MCQ counterpart to validate_dragdrop(): exactly 4 option slots — the
	 * first 3 holding distinct distractors, the 4th always blank — and the
	 * SAME Harvard-format/bibliographic-consistency/answer-leakage checks
	 * already used for DragDrop applied to the correct answer's own text
	 * (reconstructedReference). Citex constructs that answer itself (see
	 * Citex_AI_V2::normalise_mcq_item()), so it must satisfy exactly the
	 * same format rules DragDrop's reconstructed reference does. The
	 * correct answer is never placed into, or duplicated into, any option
	 * slot — it lives ONLY in the Answer field (see write_mcq_acf_values()
	 * in class-citex-populator.php).
	 */
	private static function validate_mcq( $question ) {
		$errors   = array();
		$category = (string) ( $question['category'] ?? Citex_Reference_Rules::CATEGORY_BOOK );
		$options  = is_array( $question['options'] ?? null ) ? array_values( $question['options'] ) : array();

		if ( 4 !== count( $options ) ) {
			$errors[] = self::error( 'MCQ_OPTION_COUNT_MISMATCH', sprintf( 'Exactly 4 option slots are required (3 distractors + 1 blank); %d were provided.', count( $options ) ) );
			return self::result( 'failed', $errors, null );
		}

		// Option 1-3 hold the 3 distractors; Option 4 is ALWAYS left blank.
		// The correct answer lives only in the Answer field
		// (reconstructedReference, below) — it must never be placed into, or
		// duplicated into, any option slot. This is the direct fix for a
		// real reported bug: placing the correct reference into one of the
		// 4 option slots AND into the Answer field made the student app
		// render the two copies as separate, simultaneously-"selected"
		// choices.
		for ( $i = 0; $i < 3; $i++ ) {
			if ( '' === trim( (string) $options[ $i ] ) ) {
				$errors[] = self::error( 'MCQ_OPTION_EMPTY', sprintf( 'Option %d is empty; the first 3 options must each hold a distractor.', $i + 1 ) );
			}
		}
		if ( '' !== trim( (string) $options[3] ) ) {
			$errors[] = self::error( 'MCQ_FOURTH_OPTION_NOT_BLANK', 'Option 4 must be left blank — the correct answer belongs only in the Answer field, never duplicated into an option.' );
		}

		$seen = array();
		foreach ( $options as $index => $option ) {
			$normal = strtolower( trim( preg_replace( '/\s+/', ' ', (string) $option ) ) );
			if ( '' === $normal ) {
				continue;
			}
			if ( isset( $seen[ $normal ] ) ) {
				$errors[] = self::error( 'MCQ_DUPLICATE_OPTION', sprintf( 'Option %d duplicates another option.', $index + 1 ) );
			}
			$seen[ $normal ] = true;
		}

		$place        = $question['place'] ?? null;
		$publisher    = $question['publisher'] ?? null;
		$designation  = self::expected_designation_for( $question, $category );
		$editor_join  = self::expected_editor_join_for( $question, $category );
		$reference    = trim( (string) ( $question['reconstructedReference'] ?? '' ) );
		if ( '' === $reference ) {
			$errors[] = self::error( 'MCQ_ANSWER_MISSING', 'The correct answer (reconstructedReference) is missing.' );
			return self::result( 'failed', $errors, null );
		}
		$errors = array_merge( $errors, self::validate_reference_format( $reference, $category, $place, $publisher, $designation, $editor_join ) );

		$correct_normal = strtolower( trim( preg_replace( '/\s+/', ' ', $reference ) ) );
		foreach ( $options as $index => $option ) {
			$option_text = trim( (string) $option );
			if ( '' === $option_text ) {
				continue;
			}
			// The correct answer must never appear as an option — it
			// belongs only in the Answer field.
			if ( strtolower( trim( preg_replace( '/\s+/', ' ', $option_text ) ) ) === $correct_normal ) {
				$errors[] = self::error(
					'MCQ_OPTION_MATCHES_ANSWER',
					sprintf( 'Option %d duplicates the correct answer — the answer must appear ONLY in the Answer field, never as an option.', $index + 1 )
				);
				continue;
			}
			// No distractor may itself look like a fully valid Harvard
			// reference — that would be a second plausible answer, exactly
			// the ambiguity a real MCQ must never contain.
			if ( empty( self::validate_reference_format( $option_text, $category, $place, $publisher, $designation, $editor_join ) ) ) {
				$errors[] = self::error(
					'MCQ_DISTRACTOR_LOOKS_CORRECT',
					sprintf( 'Option %d passes every Harvard format rule too — this creates a second plausible answer.', $index + 1 )
				);
			}
		}

		$question_parts = array(
			trim( (string) ( $question['authorSurname'] ?? '' ) ),
			trim( (string) ( $question['authorInitials'] ?? '' ) ),
			trim( (string) ( $question['year'] ?? '' ) ),
			trim( (string) ( $question['bookTitle'] ?? '' ) ),
		);
		// $check_scenario = false: MCQ's question text is Citex's own fixed,
		// category-generic stem (see Citex_Reference_Rules::mcq_question_stem()),
		// checked below instead via MCQ_QUESTION_STEM_MISMATCH — the
		// reference-must-contain-the-facts checks still run unchanged.
		$errors = array_merge( $errors, self::validate_consistency( $question, $question_parts, $reference, $category, false ) );
		$errors = array_merge( $errors, self::validate_answer_leakage( $question ) );

		// MCQ's question text must be exactly Citex's own fixed,
		// category-specific stem — never a per-book description (that would
		// re-open the exact leakage class removed by taking scenario-writing
		// away from Gemini for MCQ) and never anything else Gemini might
		// have supplied (Gemini is not even asked for a scenario anymore —
		// see schema_mcq()/schema_edited_book_mcq() — so this also catches
		// any stray value slipping through some other path).
		$expected_stem = Citex_Reference_Rules::mcq_question_stem( $category );
		if ( trim( (string) ( $question['scenario'] ?? '' ) ) !== $expected_stem ) {
			$errors[] = self::error(
				'MCQ_QUESTION_STEM_MISMATCH',
				sprintf( 'The MCQ question text must be exactly: "%s".', $expected_stem )
			);
		}

		// The hint is written into the real "Hint" field on population (see
		// class-citex-populator.php's FIELD_HINT) — a missing one is a
		// structural gap the same way a missing Fixed Text is for DragDrop.
		if ( '' === trim( (string) ( $question['hint'] ?? '' ) ) ) {
			$errors[] = self::error( 'MCQ_HINT_MISSING', 'Hint is missing.' );
		} else {
			$errors = array_merge( $errors, self::validate_mcq_hint_safety( $question, $reference ) );
		}

		return self::result( empty( $errors ) ? 'passed' : 'failed', $errors, $reference );
	}

	/**
	 * The Hint field is shown to the student BEFORE they answer, so — unlike
	 * the (never-written-to-WordPress) answerExplanation, which is allowed
	 * to reveal the answer because nothing currently shows it before
	 * submission — it must never name or point at a specific option, and
	 * must never reproduce the correct reference's own text. Citex authors
	 * the hint deterministically from a fixed, category-generic clue (see
	 * Citex_Reference_Rules::mcq_hint()) that structurally cannot fail
	 * these checks, but they run regardless — the same "construct it
	 * correctly AND validate it independently" pattern used everywhere else
	 * in this class (e.g. MCQ_DISTRACTOR_LOOKS_CORRECT re-checking options
	 * Citex itself assembled).
	 */
	private static function validate_mcq_hint_safety( $question, $reference ) {
		$errors = array();
		$hint   = (string) ( $question['hint'] ?? '' );

		if ( preg_match( '/\b[A-D]\s+is\s+correct\b/i', $hint )
			|| preg_match( '/\bthe\s+correct\s+(option|answer)\s+is\b/i', $hint )
			|| preg_match( '/\bthe\s+answer\s+is\b/i', $hint )
			|| preg_match( '/\boption\s+(?:[1-4]|[A-D])\b/i', $hint )
		) {
			$errors[] = self::error(
				'MCQ_HINT_REVEALS_ANSWER',
				'The hint names or points directly at a specific option (e.g. a letter/number plus "is correct", or "the answer is...") — a hint must help the student reason about the rule without identifying which option is correct.'
			);
		}

		if ( '' !== trim( (string) $reference ) && self::text_contains( $hint, $reference ) ) {
			$errors[] = self::error(
				'MCQ_HINT_REPRODUCES_ANSWER',
				'The hint reproduces the full correct reference text, which reveals the answer directly.'
			);
		}

		return $errors;
	}

	/**
	 * The designation ("ed." or "eds", without parentheses) this Edited
	 * Book question's real editor count requires — null for Book (the
	 * concept doesn't apply) or when no editors are present at all. Shared
	 * by validate_dragdrop() and validate_mcq() so both compute it the same
	 * way, from Citex_Reference_Rules::designation_for_editor_count() (the
	 * same single source of truth Citex_AI_V2 uses to build the correct
	 * option/reconstruction in the first place).
	 */
	private static function expected_designation_for( $question, $category ) {
		if ( Citex_Reference_Rules::CATEGORY_EDITED_BOOK !== $category ) {
			return null;
		}
		$editors = is_array( $question['editors'] ?? null ) ? $question['editors'] : array();
		if ( empty( $editors ) ) {
			return null;
		}
		return Citex_Reference_Rules::designation_for_editor_count( count( $editors ) );
	}

	/**
	 * The correctly-joined multi-editor string ("Smith, J. and Jones, A.")
	 * this question's real editors require — null for Book, or for an
	 * Edited Book question with fewer than 2 editors (the "and" join only
	 * applies once there is more than one name to join). Mirrors
	 * expected_designation_for(): both feed validate_reference_format() the
	 * one fact it needs to detect a distractor whose mistake the generic
	 * shape regex structurally cannot see.
	 */
	private static function expected_editor_join_for( $question, $category ) {
		if ( Citex_Reference_Rules::CATEGORY_EDITED_BOOK !== $category ) {
			return null;
		}
		$editors = is_array( $question['editors'] ?? null ) ? $question['editors'] : array();
		if ( count( $editors ) < 2 ) {
			return null;
		}
		return Citex_Reference_Rules::join_editors( $editors );
	}

	/**
	 * The Harvard reference-format checks shared by DragDrop's reconstructed
	 * reference and MCQ's correct option, for every category — punctuation
	 * and spacing rules identical regardless of category. The one
	 * category-specific piece — the overall shape (does it actually look
	 * like a Book vs an Edited Book reference) — is delegated to
	 * Citex_Reference_Rules::format_regex(), the pluggable layer new
	 * categories provide instead of this method growing a new branch each
	 * time.
	 */
	private static function validate_reference_format( $reference, $category = null, $place = null, $publisher = null, $expected_designation = null, $expected_editor_join = null ) {
		$category = $category ?? Citex_Reference_Rules::CATEGORY_BOOK;
		$errors   = array();

		if ( preg_match( '/\(\s+\d{4}|\d{4}\s+\)/', $reference ) ) {
			$errors[] = self::error( 'YEAR_PARENTHESES_SPACING', 'Publication year should have no spaces inside the parentheses, for example (2019).' );
		}
		if ( preg_match( '/\(\d{4}\)\./', $reference ) ) {
			$errors[] = self::error( 'YEAR_TRAILING_PERIOD', 'Unwanted full stop after publication year.' );
		}
		if ( preg_match( '/\s+[,.;:]/', $reference ) ) {
			$errors[] = self::error( 'SPACE_BEFORE_PUNCTUATION', 'Remove extra spaces before punctuation marks in the completed reference.' );
		}
		if ( preg_match( '/:\S/', $reference ) ) {
			$errors[] = self::error( 'MISSING_SPACE_AFTER_COLON', 'A space is required after the colon between place of publication and publisher.' );
		}
		if ( ! preg_match( '/\.\s*$/', $reference ) ) {
			$errors[] = self::error( 'MISSING_FINAL_PERIOD', 'Missing final full stop.' );
		}

		// Liverpool Hope shape for this category — Surname, I. (Year) Title.
		// Place: Publisher. for Book; Editor(s), I. (ed.|eds) (Year) Title.
		// Place: Publisher. for Edited Book.
		if ( ! preg_match( Citex_Reference_Rules::format_regex( $category ), $reference ) ) {
			$code    = Citex_Reference_Rules::CATEGORY_EDITED_BOOK === $category ? 'EDITED_BOOK_FORMAT_MISMATCH' : 'BOOK_FORMAT_MISMATCH';
			$message = Citex_Reference_Rules::CATEGORY_EDITED_BOOK === $category
				? 'Citation does not match the Liverpool Hope Edited Book format.'
				: 'Citation does not match the Liverpool Hope Book format.';
			$errors[] = self::error( $code, $message );
		}

		// Place/publisher ORDER — "Place: Publisher.", never the reverse.
		// The shape regex above cannot tell a place from a publisher; any
		// non-empty "X: Y." satisfies it equally whichever way round X and Y
		// are. That blind spot is exactly why an MCQ distractor built by
		// swapping place and publisher (a real, common Harvard mistake — see
		// Citex_Reference_Rules::mcq_distractor_patterns()) used to slip past
		// every check above and get flagged as a second "fully valid"
		// option. When the record's real place/publisher are known, check
		// the literal ordering directly instead of trusting the generic
		// shape: this can only ever fire on the SWAPPED pairing, so it never
		// flags the correct option (Citex always builds it in the right
		// order) and never weakens any check above — it only closes a gap
		// those checks structurally cannot see.
		if ( null !== $place && null !== $publisher ) {
			$place_trim     = trim( (string) $place );
			$publisher_trim = trim( (string) $publisher );
			if ( '' !== $place_trim && '' !== $publisher_trim ) {
				$correct_order = $place_trim . ': ' . $publisher_trim;
				$swapped_order = $publisher_trim . ': ' . $place_trim;
				if ( ! self::text_contains( $reference, $correct_order ) && self::text_contains( $reference, $swapped_order ) ) {
					$errors[] = self::error(
						'PLACE_PUBLISHER_ORDER_MISMATCH',
						'Place of publication and publisher appear to be swapped — Harvard requires "Place: Publisher.", not "Publisher: Place.".'
					);
				}
			}
		}

		// Edited Book designation vs. editor count — the exact same blind
		// spot as place/publisher above, and arguably the more important
		// one: the shape regex accepts EITHER "(ed.)" or "(eds)" as valid on
		// their own, so it cannot tell whether the designation actually
		// matches THIS question's editor count. A distractor using the
		// wrong designation for the stated editor count (a real, explicitly
		// required distractor pattern — "must not accidentally use (ed.)
		// for a book with multiple editors") used to slip past every check
		// above unnoticed. When the record's real editor count is known,
		// check directly: this only ever fires on the WRONG designation, so
		// it never flags the correct option (Citex always builds it with
		// the right one) and never weakens EDITED_BOOK_DESIGNATION_MISMATCH's
		// existing meaning — it only applies that same rule to every option,
		// not just the one marked correct.
		if ( Citex_Reference_Rules::CATEGORY_EDITED_BOOK === $category && null !== $expected_designation && '' !== trim( (string) $expected_designation ) ) {
			$expected = trim( (string) $expected_designation );
			$wrong    = 'ed.' === $expected ? 'eds' : 'ed.';
			if ( ! self::text_contains( $reference, '(' . $expected . ')' ) && self::text_contains( $reference, '(' . $wrong . ')' ) ) {
				$errors[] = self::error(
					'EDITED_BOOK_DESIGNATION_MISMATCH',
					sprintf( 'The reference uses "(%1$s)" instead of the "(%2$s)" required for this question\'s editor count.', $wrong, $expected )
				);
			}
		}

		// Multi-editor joining — "Smith, J. and Jones, A.", never a comma
		// throughout. Same blind spot again: the shape regex's leading `.+`
		// swallows the whole editor-name segment however it is punctuated,
		// so a distractor that replaces " and " with ", " is otherwise
		// indistinguishable from correct. Only checked when we know the
		// exact correct join AND the comma-joined variant would actually
		// differ from it (i.e. there genuinely is an "and" to omit).
		if ( Citex_Reference_Rules::CATEGORY_EDITED_BOOK === $category && null !== $expected_editor_join ) {
			$correct_join = trim( (string) $expected_editor_join );
			if ( '' !== $correct_join && false !== strpos( $correct_join, ' and ' ) ) {
				$comma_joined = str_replace( ' and ', ', ', $correct_join );
				if ( $comma_joined !== $correct_join && ! self::text_contains( $reference, $correct_join ) && self::text_contains( $reference, $comma_joined ) ) {
					$errors[] = self::error(
						'EDITED_BOOK_EDITOR_JOIN_MISMATCH',
						'Two or more editors must be joined with "and" before the last name (e.g. "Smith, J. and Jones, A."), not a comma throughout.'
					);
				}
			}
		}

		return $errors;
	}

	/**
	 * ANSWER_LEAKAGE — a generated scenario must give the student enough
	 * bibliographic information to CONSTRUCT the Harvard reference, never
	 * enough to simply copy an answer that is already spelled out. A real
	 * example this was written to catch: "...by Alan Bryman (initials A.),
	 * published in 2012..." — the parenthetical hands the student one of
	 * the four draggable Question Parts directly.
	 *
	 * This is deliberately NOT "does the scenario contain the surname" —
	 * that is required, correct, and already checked by
	 * validate_bibliographic_consistency() (a full name like "Alan Bryman"
	 * naturally contains "Bryman"). The distinction this method enforces is
	 * between natural bibliographic information and an answer being
	 * explicitly labelled or handed over pre-formatted:
	 *
	 * 1. The words "initial"/"initials" or "surname" never belong in a
	 *    natural scenario at all — their presence means an answer is being
	 *    named as an answer, not just given as information.
	 * 2. An abbreviated or completed Harvard citation embedded in the
	 *    scenario (e.g. "Bryman, A." or "Bryman, A. (2012) ...") hands the
	 *    student the exact answer format, checked against the canonical
	 *    surname specifically so this cannot misfire on unrelated text.
	 * 3. The literal initials value appearing as its own token (e.g. "use
	 *    A." or "(A.)"), not merely as part of a longer word.
	 *
	 * Runs for every Book/DragDrop question (validate() has already
	 * confirmed the format above) regardless of whether a canonical record
	 * is present — the word-ban checks are meaningful either way; the
	 * citation/initials-value checks simply no-op without a canonical
	 * surname/initials to check against.
	 */
	private static function validate_answer_leakage( $question ) {
		$errors   = array();
		$scenario = (string) ( $question['scenario'] ?? '' );
		if ( '' === trim( $scenario ) ) {
			return $errors;
		}

		if ( preg_match( '/\binitials?\b/i', $scenario ) ) {
			$errors[] = self::error(
				'ANSWER_LEAKAGE_INITIALS_WORD',
				'The scenario uses the word "initial"/"initials", which explicitly labels a draggable answer. State the author\'s full name instead and let the student derive the initials.'
			);
		}
		if ( preg_match( '/\bsurname\b/i', $scenario ) ) {
			$errors[] = self::error(
				'ANSWER_LEAKAGE_SURNAME_WORD',
				'The scenario uses the word "surname", which explicitly labels a draggable answer. State the author\'s full name instead.'
			);
		}

		// One person (Book: authorSurname/authorInitials) or several
		// (Edited Book: $question['editors']) — every one of them is
		// checked identically, since a leak of ANY editor's abbreviated
		// citation or initials value is just as much an answer leak.
		$people = array();
		$surname  = trim( (string) ( $question['authorSurname'] ?? '' ) );
		$initials = trim( (string) ( $question['authorInitials'] ?? '' ) );
		if ( '' !== $surname || '' !== $initials ) {
			$people[] = array( 'surname' => $surname, 'initials' => $initials );
		}
		foreach ( (array) ( $question['editors'] ?? array() ) as $editor ) {
			$people[] = array(
				'surname'  => trim( (string) ( $editor['surname'] ?? '' ) ),
				'initials' => trim( (string) ( $editor['initials'] ?? '' ) ),
			);
		}

		foreach ( $people as $person ) {
			if ( '' !== $person['surname'] && preg_match( '/' . preg_quote( $person['surname'], '/' ) . '\s*,\s*[A-Z]\.(?:\s?[A-Z]\.)*/u', $scenario ) ) {
				$errors[] = self::error(
					'ANSWER_LEAKAGE_ABBREVIATED_CITATION',
					'The scenario contains an abbreviated or completed Harvard citation (e.g. "Surname, I."), which hands the student the answer directly.'
				);
			}

			if ( '' !== $person['initials'] && preg_match( '/(?<![A-Za-z.])' . preg_quote( $person['initials'], '/' ) . '(?![A-Za-z])/u', $scenario ) ) {
				$errors[] = self::error(
					'ANSWER_LEAKAGE_INITIALS_VALUE',
					sprintf( 'The scenario contains the literal initials value "%s" as a standalone token, revealing a draggable answer directly.', $person['initials'] )
				);
			}
		}

		// Edited Book only: the editor designation itself ("(ed.)"/"(eds)")
		// is a Question Part / MCQ answer-defining token, exactly like
		// initials are for Book — it must never already appear in the
		// scenario.
		if ( preg_match( '/\(\s*eds?\.?\s*\)/i', $scenario ) ) {
			$errors[] = self::error(
				'ANSWER_LEAKAGE_DESIGNATION_VALUE',
				'The scenario already shows "(ed.)"/"(eds)", revealing the editor-designation answer directly.'
			);
		}

		return $errors;
	}

	/**
	 * BIBLIOGRAPHIC_CONSISTENCY — the safety net for the academic-integrity
	 * bug where a generated question's scenario described one real book while
	 * its Question Parts/Fixed Text were built from a different one (both
	 * internally self-consistent, so earlier checks never caught it). This
	 * only runs when the pending record actually carries a canonical
	 * bibliographic record (authorSurname/bookTitle) — Citex-generated
	 * questions always do (see Citex_AI_V2::normalise()); externally
	 * imported records that never captured one are unaffected, so nothing
	 * that previously passed import validation is weakened.
	 *
	 * A generated record's Question Parts and Fixed Text are themselves now
	 * *constructed* from this same canonical record (Citex is the sole
	 * source of truth for both — see Citex_AI_V2::normalise()), so checks
	 * 1-10 below are a deliberate, defensive second confirmation rather than
	 * the only line of defence. Check 11 (the scenario) is the one novel
	 * gap: nothing else in this class, or in Citex_AI_V2, ever inspects the
	 * scenario's own wording against the bibliographic facts.
	 */
	private static function validate_bibliographic_consistency( $question, $question_parts, $reference, $check_scenario = true ) {
		$errors = array();

		$canonical = array(
			'authorSurname'  => trim( (string) ( $question['authorSurname'] ?? '' ) ),
			'authorInitials' => trim( (string) ( $question['authorInitials'] ?? '' ) ),
			'year'           => trim( (string) ( $question['year'] ?? '' ) ),
			'bookTitle'      => trim( (string) ( $question['bookTitle'] ?? '' ) ),
			'place'          => trim( (string) ( $question['place'] ?? '' ) ),
			'publisher'      => trim( (string) ( $question['publisher'] ?? '' ) ),
		);

		if ( '' === $canonical['authorSurname'] && '' === $canonical['bookTitle'] ) {
			return $errors;
		}

		// 1-4: Question Parts must be exactly [surname, initials, year, title].
		$parts_padded  = array_slice( array_pad( array_map( 'trim', $question_parts ), 4, '' ), 0, 4 );
		$expected_parts = array( $canonical['authorSurname'], $canonical['authorInitials'], $canonical['year'], $canonical['bookTitle'] );
		if ( $expected_parts !== $parts_padded ) {
			$errors[] = self::error(
				'BIBLIOGRAPHIC_CONSISTENCY_PARTS_MISMATCH',
				'Question Parts do not exactly match the canonical bibliographic record (surname, initials, year, title).'
			);
		}

		// 5-10: the reconstructed reference must contain every canonical fact.
		foreach (
			array(
				'authorSurname'  => 'author surname',
				'authorInitials' => 'author initials',
				'year'           => 'publication year',
				'bookTitle'      => 'book title',
				'place'          => 'place of publication',
				'publisher'      => 'publisher',
			) as $field => $label
		) {
			if ( '' !== $canonical[ $field ] && ! self::text_contains( $reference, $canonical[ $field ] ) ) {
				$errors[] = self::error(
					'BIBLIOGRAPHIC_CONSISTENCY_REFERENCE_MISMATCH',
					sprintf( 'The reconstructed reference does not contain the canonical %s: "%s".', $label, $canonical[ $field ] )
				);
			}
		}

		// 11: the scenario must identify the same bibliographic record. Author
		// initials are deliberately excluded here: a natural scenario names the
		// author (e.g. "Stella Cottrell"), not their initials, so checking
		// initials against the scenario text would reject genuinely correct
		// scenarios.
		//
		// Skipped when $check_scenario is false (MCQ): its scenario is now
		// Citex's own fixed, category-generic question stem, which by
		// design names no book-specific fact at all — checking it against
		// the canonical record would always fail, for the right reason
		// (nothing to leak) rather than a real inconsistency.
		if ( $check_scenario ) {
			$scenario = (string) ( $question['scenario'] ?? '' );
			foreach (
				array(
					'bookTitle'     => 'book title',
					'authorSurname' => 'author surname',
					'year'          => 'publication year',
					'place'         => 'place of publication',
					'publisher'     => 'publisher',
				) as $field => $label
			) {
				if ( '' !== $canonical[ $field ] && ! self::text_contains( $scenario, $canonical[ $field ] ) ) {
					$errors[] = self::error(
						'BIBLIOGRAPHIC_CONSISTENCY_SCENARIO_MISMATCH',
						sprintf( 'The scenario does not mention the canonical %s: "%s".', $label, $canonical[ $field ] )
					);
				}
			}
		}

		return $errors;
	}

	/**
	 * Edited Book counterpart to validate_bibliographic_consistency() — the
	 * same academic-integrity safety net (scenario must describe the same
	 * source the reference/Question Parts were built from), reshaped for
	 * one-or-more editors instead of a single author. Also independently
	 * confirms the editor DESIGNATION used in the reference actually
	 * matches the editor count — "must not accidentally use (ed.) for a
	 * book with multiple editors", explicitly required and tested.
	 */
	private static function validate_edited_book_consistency( $question, $reference, $check_scenario = true ) {
		$errors  = array();
		$editors = is_array( $question['editors'] ?? null ) ? array_values( $question['editors'] ) : array();
		$title   = trim( (string) ( $question['bookTitle'] ?? '' ) );

		if ( empty( $editors ) && '' === $title ) {
			return $errors;
		}

		if ( empty( $editors ) ) {
			$errors[] = self::error( 'EDITED_BOOK_EDITORS_MISSING', 'No editors were provided for this Edited Book question.' );
			return $errors;
		}

		$year      = trim( (string) ( $question['year'] ?? '' ) );
		$place     = trim( (string) ( $question['place'] ?? '' ) );
		$publisher = trim( (string) ( $question['publisher'] ?? '' ) );

		$expected_designation = Citex_Reference_Rules::designation_for_editor_count( count( $editors ) );
		if ( ! self::text_contains( $reference, '(' . $expected_designation . ')' ) ) {
			$errors[] = self::error(
				'EDITED_BOOK_DESIGNATION_MISMATCH',
				sprintf(
					'The reference does not contain "(%1$s)", the designation required for %2$d editor(s) — it must never use "(ed.)" for multiple editors or "(eds)" for a single editor.',
					$expected_designation,
					count( $editors )
				)
			);
		}

		foreach ( $editors as $index => $editor ) {
			$editor_surname  = trim( (string) ( $editor['surname'] ?? '' ) );
			$editor_initials = trim( (string) ( $editor['initials'] ?? '' ) );
			if ( '' !== $editor_surname && ! self::text_contains( $reference, $editor_surname ) ) {
				$errors[] = self::error( 'EDITED_BOOK_REFERENCE_MISMATCH', sprintf( 'The reference does not contain editor %1$d\'s surname: "%2$s".', $index + 1, $editor_surname ) );
			}
			if ( '' !== $editor_initials && ! self::text_contains( $reference, $editor_initials ) ) {
				$errors[] = self::error( 'EDITED_BOOK_REFERENCE_MISMATCH', sprintf( 'The reference does not contain editor %1$d\'s initials: "%2$s".', $index + 1, $editor_initials ) );
			}
			if ( $check_scenario && '' !== $editor_surname && ! self::text_contains( (string) ( $question['scenario'] ?? '' ), $editor_surname ) ) {
				$errors[] = self::error( 'EDITED_BOOK_SCENARIO_MISMATCH', sprintf( 'The scenario does not mention editor %1$d\'s surname: "%2$s".', $index + 1, $editor_surname ) );
			}
		}

		foreach (
			array(
				'year'      => array( $year, 'publication year' ),
				'title'     => array( $title, 'book title' ),
				'place'     => array( $place, 'place of publication' ),
				'publisher' => array( $publisher, 'publisher' ),
			) as $pair
		) {
			list( $value, $label ) = $pair;
			if ( '' !== $value && ! self::text_contains( $reference, $value ) ) {
				$errors[] = self::error( 'EDITED_BOOK_REFERENCE_MISMATCH', sprintf( 'The reference does not contain the canonical %1$s: "%2$s".', $label, $value ) );
			}
		}

		// Scenario check (11's counterpart): title, year, place, publisher —
		// editor names are already checked per-editor above; initials are
		// excluded here for the same reason Book excludes them (a natural
		// scenario names the editor, not their initials).
		//
		// Skipped when $check_scenario is false (MCQ) — see the matching
		// comment in validate_bibliographic_consistency() for why: MCQ's
		// scenario is now Citex's own fixed, category-generic stem that by
		// design names no book-specific fact.
		if ( $check_scenario ) {
			$scenario = (string) ( $question['scenario'] ?? '' );
			foreach (
				array(
					'title'     => array( $title, 'book title' ),
					'year'      => array( $year, 'publication year' ),
					'place'     => array( $place, 'place of publication' ),
					'publisher' => array( $publisher, 'publisher' ),
				) as $pair
			) {
				list( $value, $label ) = $pair;
				if ( '' !== $value && ! self::text_contains( $scenario, $value ) ) {
					$errors[] = self::error( 'EDITED_BOOK_SCENARIO_MISMATCH', sprintf( 'The scenario does not mention the canonical %1$s: "%2$s".', $label, $value ) );
				}
			}
		}

		return $errors;
	}

	/**
	 * Case-insensitive substring containment, not exact string matching —
	 * natural-language scenario phrasing varies ("You are referencing..." vs
	 * "You are creating a reference for..."), so each canonical fact only
	 * needs to appear somewhere in the text, not match it word-for-word.
	 */
	private static function text_contains( $haystack, $needle ) {
		$haystack = self::normalise_for_match( $haystack );
		$needle   = self::normalise_for_match( $needle );
		return '' !== $needle && false !== mb_stripos( $haystack, $needle );
	}

	private static function normalise_for_match( $value ) {
		$value = (string) $value;
		$value = str_replace( array( "\xE2\x80\x99", "\xE2\x80\x98" ), "'", $value ); // curly quotes -> straight
		$value = preg_replace( '/\s+/', ' ', $value );
		return trim( (string) $value );
	}

	/**
	 * Parse the confirmed Citex DragDrop grammar:
	 * - a single | may represent the first slot;
	 * - || represents internal slots;
	 * - a final single | may be followed only by fixed punctuation/whitespace.
	 */
	private static function reconstruct( $fixed_text, $parts ) {
		$fixed_text = (string) $fixed_text;
		$tokens     = array();
		$length     = strlen( $fixed_text );
		$i          = 0;

		while ( $i < $length ) {
			if ( '|' !== $fixed_text[ $i ] ) {
				$tokens[] = array( 'type' => 'text', 'value' => $fixed_text[ $i ] );
				$i++;
				continue;
			}

			if ( $i + 1 < $length && '|' === $fixed_text[ $i + 1 ] ) {
				$tokens[] = array( 'type' => 'slot', 'value' => '||' );
				$i += 2;
				continue;
			}

			$before = substr( $fixed_text, 0, $i );
			$after  = substr( $fixed_text, $i + 1 );
			$is_first = '' === trim( $before );
			$is_final = 1 === preg_match( '/^[\s\.,;:!?\-–—]*$/u', $after );

			if ( ! $is_first && ! $is_final ) {
				return new WP_Error( 'MALFORMED_PLACEHOLDER_ENCODING', 'Fixed Text contains a single "|" in an internal position; internal draggable placeholders must use "||".' );
			}

			$tokens[] = array( 'type' => 'slot', 'value' => '|' );
			$i++;
		}

		$slot_count = 0;
		foreach ( $tokens as $token ) {
			if ( 'slot' === $token['type'] ) {
				$slot_count++;
			}
		}

		if ( $slot_count !== count( $parts ) ) {
			return new WP_Error(
				'PLACEHOLDER_COUNT_MISMATCH',
				sprintf( 'Fixed Text contains %d draggable placeholder(s), but there are %d Question Part(s).', $slot_count, count( $parts ) )
			);
		}

		$reference = '';
		$part_index = 0;
		foreach ( $tokens as $token ) {
			if ( 'slot' === $token['type'] ) {
				$reference .= (string) $parts[ $part_index++ ];
			} else {
				$reference .= $token['value'];
			}
		}

		return array(
			'reference'       => trim( $reference ),
			'placeholderCount'=> $slot_count,
		);
	}

	private static function error( $code, $message ) {
		return array(
			'code'    => sanitize_key( $code ),
			'message' => (string) $message,
		);
	}

	private static function result( $status, $errors, $reference ) {
		return array(
			'status'                 => $status,
			'errors'                 => array_values( $errors ),
			'reconstructedReference' => $reference,
			'validatedAt'            => gmdate( 'c' ),
		);
	}
}
